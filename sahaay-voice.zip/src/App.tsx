/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useCallback, useEffect, useState } from 'react';
import { ChatMessage, Language, NavTab } from './types/sahaay';
import { matchQuestionIntent } from './utils/intentMatcher';
import { useSpeech } from './hooks/useSpeech';
import { TopBar } from './components/TopBar';
import { MobileBottomNav } from './components/MobileBottomNav';
import { VoiceHome } from './components/VoiceHome';
import { TopicsView } from './components/TopicsView';
import { ChecklistView } from './components/ChecklistView';
import { FaqView } from './components/FaqView';
import { DisclaimerBanner } from './components/DisclaimerBanner';

const CHECKLIST_STORAGE_KEY = 'sahaay_voice_checklist_v1';
const LANGUAGE_STORAGE_KEY = 'sahaay_voice_lang_v1';

function formatNow(): string {
  try {
    return new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  } catch {
    return '';
  }
}

export default function App() {
  const [language, setLanguage] = useState<Language>(() => {
    try {
      const saved = localStorage.getItem(LANGUAGE_STORAGE_KEY);
      if (saved === 'en' || saved === 'hi' || saved === 'gu') return saved;
    } catch {
      // Ignore storage errors
    }
    return 'en';
  });

  const [activeTab, setActiveTab] = useState<NavTab>('home');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [autoSpeak, setAutoSpeak] = useState<boolean>(true);
  const [checkedIds, setCheckedIds] = useState<string[]>(() => {
    try {
      const raw = localStorage.getItem(CHECKLIST_STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch {
      // Ignore storage errors
    }
    return [];
  });

  const {
    isRecognitionSupported,
    isTtsSupported,
    isListening,
    interimTranscript,
    micError,
    clearMicError,
    speakingId,
    startListening,
    stopListening,
    speak,
    stopSpeaking,
  } = useSpeech(language);

  useEffect(() => {
    document.documentElement.lang = language;
    try {
      localStorage.setItem(LANGUAGE_STORAGE_KEY, language);
    } catch {
      // Ignore storage errors
    }
  }, [language]);

  useEffect(() => {
    try {
      localStorage.setItem(CHECKLIST_STORAGE_KEY, JSON.stringify(checkedIds));
    } catch {
      // Ignore storage errors
    }
  }, [checkedIds]);

  const handleLanguageChange = useCallback(
    (nextLang: Language) => {
      stopSpeaking();
      stopListening();
      clearMicError();
      setLanguage(nextLang);
    },
    [clearMicError, stopListening, stopSpeaking]
  );

  const handleTabChange = useCallback(
    (nextTab: NavTab) => {
      if (isListening) {
        stopListening();
      }
      setActiveTab(nextTab);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    },
    [isListening, stopListening]
  );

  const handleAskQuestion = useCallback(
    (rawQuery: string, targetLang: Language = language) => {
      const query = rawQuery.trim();
      if (!query) return;

      const intent = matchQuestionIntent(query);
      const timeLabel = formatNow();
      const userId = `u-${Date.now()}`;
      const assistantId = `a-${Date.now() + 1}`;

      const userMsg: ChatMessage = {
        id: userId,
        role: 'user',
        text: query,
        timestamp: timeLabel,
      };

      const title = intent.title[targetLang];
      const summary = intent.summary[targetLang];
      const points = intent.points[targetLang];
      const note = intent.note?.[targetLang];

      const assistantMsg: ChatMessage = {
        id: assistantId,
        role: 'assistant',
        title,
        text: summary,
        points,
        note,
        followUps: intent.followUps,
        isSafetyNotice: intent.category === 'safety',
        timestamp: timeLabel,
      };

      setMessages((prev) => [...prev, userMsg, assistantMsg]);
      setActiveTab('home');

      if (autoSpeak && isTtsSupported) {
        const speechText = [title, summary, ...points, note].filter(Boolean).join('. ');
        speak(speechText, assistantId);
      }
    },
    [autoSpeak, isTtsSupported, language, speak]
  );

  const handleStartListening = useCallback(() => {
    startListening((spokenText) => {
      handleAskQuestion(spokenText);
    });
  }, [handleAskQuestion, startListening]);

  const handleClearConversation = useCallback(() => {
    stopSpeaking();
    stopListening();
    clearMicError();
    setMessages([]);
  }, [clearMicError, stopListening, stopSpeaking]);

  const handleToggleChecklistItem = useCallback((id: string) => {
    setCheckedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  }, []);

  const handleResetChecklist = useCallback(() => {
    setCheckedIds([]);
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-[#f6fbf9] text-[#0f2926]">
      <TopBar
        language={language}
        onLanguageChange={handleLanguageChange}
        activeTab={activeTab}
        onTabChange={handleTabChange}
      />

      <main className="flex-1">
        {activeTab === 'home' && (
          <VoiceHome
            language={language}
            messages={messages}
            autoSpeak={autoSpeak}
            onToggleAutoSpeak={() => {
              if (autoSpeak) stopSpeaking();
              setAutoSpeak((prev) => !prev);
            }}
            onAskQuestion={(q) => handleAskQuestion(q)}
            onClearConversation={handleClearConversation}
            isRecognitionSupported={isRecognitionSupported}
            isTtsSupported={isTtsSupported}
            isListening={isListening}
            interimTranscript={interimTranscript}
            micError={micError}
            speakingId={speakingId}
            onStartListening={handleStartListening}
            onStopListening={stopListening}
            onSpeakText={speak}
            onStopSpeaking={stopSpeaking}
          />
        )}

        {activeTab === 'topics' && (
          <TopicsView
            language={language}
            isTtsSupported={isTtsSupported}
            speakingId={speakingId}
            onSpeakText={speak}
            onStopSpeaking={stopSpeaking}
            onAskInVoiceChat={(q) => handleAskQuestion(q)}
          />
        )}

        {activeTab === 'checklist' && (
          <ChecklistView
            language={language}
            checkedIds={checkedIds}
            onToggleItem={handleToggleChecklistItem}
            onResetChecklist={handleResetChecklist}
            isTtsSupported={isTtsSupported}
            speakingId={speakingId}
            onSpeakText={speak}
            onStopSpeaking={stopSpeaking}
          />
        )}

        {activeTab === 'faq' && (
          <FaqView
            language={language}
            isTtsSupported={isTtsSupported}
            speakingId={speakingId}
            onSpeakText={speak}
            onStopSpeaking={stopSpeaking}
            onAskInVoiceChat={(q) => handleAskQuestion(q)}
          />
        )}
      </main>

      <DisclaimerBanner language={language} />

      <MobileBottomNav
        language={language}
        activeTab={activeTab}
        onTabChange={handleTabChange}
      />
    </div>
  );
}
