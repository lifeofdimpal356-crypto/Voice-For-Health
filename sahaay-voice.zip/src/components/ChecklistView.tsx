import { Check, RotateCcw, Square, Volume2 } from 'lucide-react';
import { Language } from '../types/sahaay';
import { UI_STRINGS } from '../data/translations';
import { ADMISSION_CHECKLIST } from '../data/knowledgeBase';

interface ChecklistViewProps {
  language: Language;
  checkedIds: string[];
  onToggleItem: (id: string) => void;
  onResetChecklist: () => void;
  isTtsSupported: boolean;
  speakingId: string | null;
  onSpeakText: (text: string, id: string) => void;
  onStopSpeaking: () => void;
}

export function ChecklistView({
  language,
  checkedIds,
  onToggleItem,
  onResetChecklist,
  isTtsSupported,
  speakingId,
  onSpeakText,
  onStopSpeaking,
}: ChecklistViewProps) {
  const t = UI_STRINGS[language];
  const totalCount = ADMISSION_CHECKLIST.length;
  const readyCount = checkedIds.length;
  const progressPercent = Math.round((readyCount / totalCount) * 100);
  const checklistSpeechId = 'checklist-all';
  const isSpeakingChecklist = speakingId === checklistSpeechId;

  const handleListenAll = () => {
    if (isSpeakingChecklist) {
      onStopSpeaking();
      return;
    }
    const itemsText = ADMISSION_CHECKLIST.map(
      (item, idx) => `${idx + 1}. ${item.title[language]}. ${item.detail[language]}`
    ).join('. ');
    onSpeakText(`${t.sections.checklistTitle}. ${itemsText}`, checklistSpeechId);
  };

  return (
    <section className="max-w-4xl mx-auto px-4 sm:px-6 pt-6 sm:pt-8 space-y-6">
      <div className="space-y-1.5">
        <h1 className="text-2xl sm:text-3xl font-bold text-teal-950">
          {t.sections.checklistTitle}
        </h1>
        <p className="text-base text-slate-600">{t.sections.checklistSubtitle}</p>
      </div>

      {/* Progress & Action Bar */}
      <div className="bg-white border border-teal-200 rounded-3xl p-5 sm:p-6 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <div className="text-sm font-semibold text-slate-600">
              {t.sections.checklistProgress}
            </div>
            <div className="text-2xl font-bold text-teal-900 tabular-nums">
              {readyCount} {t.labels.of} {totalCount} {t.labels.ready}
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            {isTtsSupported && (
              <button
                type="button"
                onClick={handleListenAll}
                className={`min-h-[46px] px-4 py-2.5 rounded-2xl text-sm font-bold flex items-center gap-2 cursor-pointer transition-colors ${
                  isSpeakingChecklist
                    ? 'bg-emerald-700 text-white'
                    : 'bg-teal-700 hover:bg-teal-800 text-white'
                }`}
              >
                {isSpeakingChecklist ? (
                  <>
                    <Square className="w-4 h-4 fill-current" aria-hidden="true" />
                    <span>{t.voiceControls.stopSpeaking}</span>
                  </>
                ) : (
                  <>
                    <Volume2 className="w-4 h-4" aria-hidden="true" />
                    <span>{t.sections.checklistListenAll}</span>
                  </>
                )}
              </button>
            )}

            {readyCount > 0 && (
              <button
                type="button"
                onClick={onResetChecklist}
                className="min-h-[46px] px-4 py-2.5 rounded-2xl text-sm font-semibold bg-white border border-teal-300 text-teal-900 hover:bg-emerald-50 flex items-center gap-2 cursor-pointer transition-colors"
              >
                <RotateCcw className="w-4 h-4" aria-hidden="true" />
                <span>{t.sections.checklistReset}</span>
              </button>
            )}
          </div>
        </div>

        {/* Clean Progress Track */}
        <div
          role="progressbar"
          aria-valuenow={progressPercent}
          aria-valuemin={0}
          aria-valuemax={100}
          className="w-full h-3 bg-emerald-100 rounded-full overflow-hidden"
        >
          <div
            className="h-full bg-teal-700 transition-all duration-200"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </div>

      {/* Tap-Friendly Checklist Items */}
      <div className="space-y-3">
        {ADMISSION_CHECKLIST.map((item) => {
          const checked = checkedIds.includes(item.id);
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => onToggleItem(item.id)}
              aria-pressed={checked}
              className={`w-full min-h-[72px] p-4 sm:p-5 rounded-2xl border text-left flex items-start gap-4 cursor-pointer transition-colors ${
                checked
                  ? 'bg-emerald-50 border-teal-400'
                  : 'bg-white border-teal-200 hover:bg-emerald-50/50'
              }`}
            >
              <span
                aria-hidden="true"
                className={`mt-0.5 w-8 h-8 rounded-xl border-2 flex items-center justify-center shrink-0 transition-colors ${
                  checked
                    ? 'bg-teal-700 border-teal-700 text-white'
                    : 'bg-white border-teal-400 text-transparent'
                }`}
              >
                <Check className="w-5 h-5" strokeWidth={3} />
              </span>

              <div className="flex-1 space-y-1">
                <div className="flex flex-wrap items-baseline justify-between gap-2">
                  <span
                    className={`text-base sm:text-lg font-bold leading-snug ${
                      checked ? 'text-teal-950 line-through decoration-teal-700/50' : 'text-teal-950'
                    }`}
                  >
                    {item.title[language]}
                  </span>
                  <span className="text-xs font-medium text-teal-800">
                    {item.requiredFor[language]}
                  </span>
                </div>
                <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
                  {item.detail[language]}
                </p>
              </div>
            </button>
          );
        })}
      </div>
    </section>
  );
}
