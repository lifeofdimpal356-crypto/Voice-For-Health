import { PhoneCall, ShieldAlert } from 'lucide-react';
import { Language } from '../types/sahaay';
import { UI_STRINGS } from '../data/translations';

interface DisclaimerBannerProps {
  language: Language;
}

export function DisclaimerBanner({ language }: DisclaimerBannerProps) {
  const t = UI_STRINGS[language];

  return (
    <footer className="mt-10 pb-24 md:pb-10">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="bg-emerald-50/80 border border-teal-200/80 rounded-2xl p-5 sm:p-6">
          <div className="flex items-start gap-3.5">
            <div className="w-10 h-10 rounded-xl bg-teal-100 text-teal-800 flex items-center justify-center shrink-0">
              <ShieldAlert className="w-5 h-5" aria-hidden="true" />
            </div>
            <div className="space-y-2">
              <h2 className="text-base font-bold text-teal-950">
                {t.disclaimer.heading}
              </h2>
              <p className="text-sm leading-relaxed text-slate-700">
                {t.disclaimer.body}
              </p>
              <div className="pt-1 flex items-center gap-2 text-sm font-semibold text-teal-900">
                <PhoneCall className="w-4 h-4 shrink-0 text-teal-700" aria-hidden="true" />
                <span>{t.disclaimer.emergencyNote}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
