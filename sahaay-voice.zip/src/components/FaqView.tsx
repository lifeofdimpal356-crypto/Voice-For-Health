import { useState } from 'react';
import { ChevronDown, Mic, Square, Volume2 } from 'lucide-react';
import { Language } from '../types/sahaay';
import { UI_STRINGS } from '../data/translations';
import { FAQ_ITEMS } from '../data/knowledgeBase';

interface FaqViewProps {
  language: Language;
  isTtsSupported: boolean;
  speakingId: string | null;
  onSpeakText: (text: string, id: string) => void;
  onStopSpeaking: () => void;
  onAskInVoiceChat: (question: string) => void;
}

export function FaqView({
  language,
  isTtsSupported,
  speakingId,
  onSpeakText,
  onStopSpeaking,
  onAskInVoiceChat,
}: FaqViewProps) {
  const [openId, setOpenId] = useState<string>(FAQ_ITEMS[0].id);
  const t = UI_STRINGS[language];

  return (
    <section className="max-w-4xl mx-auto px-4 sm:px-6 pt-6 sm:pt-8 space-y-6">
      <div className="space-y-1.5">
        <h1 className="text-2xl sm:text-3xl font-bold text-teal-950">
          {t.sections.faqTitle}
        </h1>
        <p className="text-base text-slate-600">{t.sections.faqSubtitle}</p>
      </div>

      <div className="space-y-3.5">
        {FAQ_ITEMS.map((item) => {
          const isOpen = openId === item.id;
          const faqSpeechId = `faq-${item.id}`;
          const isSpeakingThis = speakingId === faqSpeechId;

          return (
            <div
              key={item.id}
              className="bg-white border border-teal-200 rounded-2xl overflow-hidden"
            >
              <button
                type="button"
                onClick={() => setOpenId(isOpen ? '' : item.id)}
                aria-expanded={isOpen}
                className="w-full min-h-[64px] p-5 text-left flex items-center justify-between gap-4 cursor-pointer hover:bg-emerald-50/50 transition-colors"
              >
                <span className="text-base sm:text-lg font-bold text-teal-950 leading-snug">
                  {item.question[language]}
                </span>
                <ChevronDown
                  className={`w-5 h-5 text-teal-700 shrink-0 transition-transform duration-200 ${
                    isOpen ? 'rotate-180' : ''
                  }`}
                  aria-hidden="true"
                />
              </button>

              {isOpen && (
                <div className="px-5 pb-5 pt-1 border-t border-teal-100 space-y-4">
                  <p className="text-base text-slate-700 leading-relaxed pt-3">
                    {item.answer[language]}
                  </p>

                  <div className="flex flex-wrap items-center gap-2.5">
                    {isTtsSupported && (
                      <button
                        type="button"
                        onClick={() =>
                          isSpeakingThis
                            ? onStopSpeaking()
                            : onSpeakText(
                                `${item.question[language]}. ${item.answer[language]}`,
                                faqSpeechId
                              )
                        }
                        className={`min-h-[44px] px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-2 cursor-pointer transition-colors ${
                          isSpeakingThis
                            ? 'bg-emerald-700 text-white'
                            : 'bg-emerald-50 text-teal-900 border border-teal-200 hover:bg-emerald-100'
                        }`}
                      >
                        {isSpeakingThis ? (
                          <>
                            <Square className="w-4 h-4 fill-current" aria-hidden="true" />
                            <span>{t.voiceControls.stopSpeaking}</span>
                          </>
                        ) : (
                          <>
                            <Volume2 className="w-4 h-4" aria-hidden="true" />
                            <span>{t.voiceControls.listenAnswer}</span>
                          </>
                        )}
                      </button>
                    )}

                    <button
                      type="button"
                      onClick={() => onAskInVoiceChat(item.followUpQuery[language])}
                      className="min-h-[44px] px-4 py-2 rounded-xl text-sm font-bold bg-teal-700 hover:bg-teal-800 text-white flex items-center gap-2 cursor-pointer transition-colors"
                    >
                      <Mic className="w-4 h-4" aria-hidden="true" />
                      <span>{t.sections.askVoiceButton}</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </section>
  );
}
