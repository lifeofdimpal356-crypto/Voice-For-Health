import { BookOpen, ClipboardCheck, HelpCircle, Mic } from 'lucide-react';
import { Language, NavTab } from '../types/sahaay';
import { UI_STRINGS } from '../data/translations';

interface MobileBottomNavProps {
  language: Language;
  activeTab: NavTab;
  onTabChange: (tab: NavTab) => void;
}

export function MobileBottomNav({
  language,
  activeTab,
  onTabChange,
}: MobileBottomNavProps) {
  const t = UI_STRINGS[language];

  const tabs: { id: NavTab; label: string; Icon: typeof Mic }[] = [
    { id: 'home', label: t.nav.home, Icon: Mic },
    { id: 'topics', label: t.nav.topics, Icon: BookOpen },
    { id: 'checklist', label: t.nav.checklist, Icon: ClipboardCheck },
    { id: 'faq', label: t.nav.faq, Icon: HelpCircle },
  ];

  return (
    <nav
      aria-label="Mobile Navigation"
      className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-teal-100"
    >
      <div className="grid grid-cols-4 h-[60px] items-center">
        {tabs.map(({ id, label, Icon }) => {
          const active = activeTab === id;
          return (
            <button
              key={id}
              type="button"
              onClick={() => onTabChange(id)}
              aria-current={active ? 'page' : undefined}
              className={`h-full min-h-[44px] flex flex-col items-center justify-center gap-0.5 px-1 cursor-pointer transition-colors ${
                active
                  ? 'text-teal-800 bg-emerald-50/70'
                  : 'text-slate-600 hover:text-teal-700'
              }`}
            >
              <Icon
                className="w-5 h-5"
                strokeWidth={active ? 2.4 : 1.9}
                aria-hidden="true"
              />
              <span className="text-[11px] font-semibold leading-tight whitespace-nowrap truncate max-w-full">
                {label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
