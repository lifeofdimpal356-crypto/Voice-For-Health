import { Language, NavTab } from '../types/sahaay';
import { UI_STRINGS } from '../data/translations';

interface TopBarProps {
  language: Language;
  onLanguageChange: (lang: Language) => void;
  activeTab: NavTab;
  onTabChange: (tab: NavTab) => void;
}

const LANG_OPTIONS: { code: Language; label: string; shortLabel: string }[] = [
  { code: 'en', label: 'English', shortLabel: 'EN' },
  { code: 'hi', label: 'हिन्दी', shortLabel: 'हिन्दी' },
  { code: 'gu', label: 'ગુજરાતી', shortLabel: 'ગુજરાતી' },
];

export function TopBar({
  language,
  onLanguageChange,
  activeTab,
  onTabChange,
}: TopBarProps) {
  const t = UI_STRINGS[language];

  const navItems: { id: NavTab; label: string }[] = [
    { id: 'home', label: t.nav.home },
    { id: 'topics', label: t.nav.topics },
    { id: 'checklist', label: t.nav.checklist },
    { id: 'faq', label: t.nav.faq },
  ];

  return (
    <header className="bg-white border-b border-teal-100 md:sticky md:top-0 md:z-30">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4 md:gap-8">
        {/* Zone 1: Single-line Wordmark */}
        <button
          type="button"
          onClick={() => onTabChange('home')}
          className="text-xl font-bold tracking-tight text-teal-900 whitespace-nowrap shrink-0 cursor-pointer hover:text-teal-700 transition-colors"
        >
          {t.appName}
        </button>

        {/* Zone 2: Desktop Navigation Links */}
        <nav
          aria-label="Primary"
          className="hidden md:flex items-center gap-7 text-sm font-medium text-slate-600"
        >
          {navItems.map((item) => {
            const active = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onTabChange(item.id)}
                className={`py-2 whitespace-nowrap shrink-0 cursor-pointer border-b-2 transition-colors ${
                  active
                    ? 'border-teal-700 text-teal-900 font-semibold'
                    : 'border-transparent hover:text-teal-800 hover:border-teal-200'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Language Switcher Control */}
        <div
          role="group"
          aria-label={t.languageLabel}
          className="flex items-center gap-1 p-1 bg-emerald-50 border border-teal-200/70 rounded-xl shrink-0"
        >
          {LANG_OPTIONS.map((opt) => {
            const active = language === opt.code;
            return (
              <button
                key={opt.code}
                type="button"
                onClick={() => onLanguageChange(opt.code)}
                aria-pressed={active}
                className={`min-h-[38px] px-2.5 sm:px-3.5 py-1.5 text-xs sm:text-sm font-semibold rounded-lg whitespace-nowrap shrink-0 cursor-pointer transition-colors ${
                  active
                    ? 'bg-teal-700 text-white shadow-xs'
                    : 'text-teal-900 hover:bg-emerald-100/80'
                }`}
              >
                <span className="sm:hidden">{opt.shortLabel}</span>
                <span className="hidden sm:inline">{opt.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
}
