import { useState } from 'react';
import {
  Building2,
  Mic,
  Receipt,
  Scale,
  Square,
  Stethoscope,
  Volume2,
} from 'lucide-react';
import { Language, TopicId } from '../types/sahaay';
import { UI_STRINGS } from '../data/translations';
import { BILL_TERMS, TOPIC_GUIDES } from '../data/knowledgeBase';

interface TopicsViewProps {
  language: Language;
  isTtsSupported: boolean;
  speakingId: string | null;
  onSpeakText: (text: string, id: string) => void;
  onStopSpeaking: () => void;
  onAskInVoiceChat: (question: string) => void;
}

const TOPIC_ICONS: Record<TopicId, typeof Stethoscope> = {
  operation: Stethoscope,
  bill: Receipt,
  schemes: Building2,
  rights: Scale,
};

export function TopicsView({
  language,
  isTtsSupported,
  speakingId,
  onSpeakText,
  onStopSpeaking,
  onAskInVoiceChat,
}: TopicsViewProps) {
  const [selectedTopicId, setSelectedTopicId] = useState<TopicId>('operation');
  const [selectedBillTermId, setSelectedBillTermId] = useState<string>(BILL_TERMS[0].id);

  const t = UI_STRINGS[language];
  const activeGuide =
    TOPIC_GUIDES.find((g) => g.id === selectedTopicId) || TOPIC_GUIDES[0];
  const activeBillTerm =
    BILL_TERMS.find((b) => b.id === selectedBillTermId) || BILL_TERMS[0];

  const guideSpeakId = `guide-${activeGuide.id}`;
  const isSpeakingGuide = speakingId === guideSpeakId;

  const buildGuideSpeech = () => {
    const parts = [activeGuide.title[language], activeGuide.intro[language]];
    for (const sec of activeGuide.sections) {
      parts.push(sec.heading[language]);
      parts.push(...sec.bullets[language]);
    }
    return parts.join('. ');
  };

  return (
    <section className="max-w-6xl mx-auto px-4 sm:px-6 pt-6 sm:pt-8 space-y-6">
      <div className="space-y-1.5">
        <h1 className="text-2xl sm:text-3xl font-bold text-teal-950">
          {t.sections.topicsTitle}
        </h1>
        <p className="text-base text-slate-600">{t.sections.topicsSubtitle}</p>
      </div>

      {/* Large Topic Selector Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {TOPIC_GUIDES.map((guide) => {
          const Icon = TOPIC_ICONS[guide.id];
          const active = guide.id === selectedTopicId;
          return (
            <button
              key={guide.id}
              type="button"
              onClick={() => setSelectedTopicId(guide.id)}
              aria-pressed={active}
              className={`min-h-[76px] p-4 rounded-2xl border text-left flex items-start gap-3.5 cursor-pointer transition-colors ${
                active
                  ? 'bg-teal-700 text-white border-teal-700 shadow-sm'
                  : 'bg-white text-teal-950 border-teal-200 hover:bg-emerald-50'
              }`}
            >
              <div
                className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                  active ? 'bg-teal-600 text-white' : 'bg-emerald-100 text-teal-800'
                }`}
              >
                <Icon className="w-5 h-5" aria-hidden="true" />
              </div>
              <div>
                <div className="text-base font-bold leading-snug">
                  {guide.title[language]}
                </div>
              </div>
            </button>
          );
        })}
      </div>

      {/* Selected Topic Guide Card */}
      <div className="bg-white border border-teal-200 rounded-3xl p-5 sm:p-8 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-teal-100">
          <div className="space-y-1">
            <h2 className="text-xl sm:text-2xl font-bold text-teal-950">
              {activeGuide.title[language]}
            </h2>
            <p className="text-sm sm:text-base text-slate-600">
              {activeGuide.subtitle[language]}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            {isTtsSupported && (
              <button
                type="button"
                onClick={() =>
                  isSpeakingGuide
                    ? onStopSpeaking()
                    : onSpeakText(buildGuideSpeech(), guideSpeakId)
                }
                className={`min-h-[46px] px-4 py-2.5 rounded-2xl text-sm font-bold flex items-center gap-2 cursor-pointer transition-colors ${
                  isSpeakingGuide
                    ? 'bg-emerald-700 text-white'
                    : 'bg-emerald-50 text-teal-900 border border-teal-200 hover:bg-emerald-100'
                }`}
              >
                {isSpeakingGuide ? (
                  <>
                    <Square className="w-4 h-4 fill-current" aria-hidden="true" />
                    <span>{t.voiceControls.stopSpeaking}</span>
                  </>
                ) : (
                  <>
                    <Volume2 className="w-4 h-4" aria-hidden="true" />
                    <span>{t.sections.listenGuideButton}</span>
                  </>
                )}
              </button>
            )}

            <button
              type="button"
              onClick={() => onAskInVoiceChat(activeGuide.sampleQuestion[language])}
              className="min-h-[46px] px-4 py-2.5 rounded-2xl text-sm font-bold bg-teal-700 hover:bg-teal-800 text-white flex items-center gap-2 cursor-pointer transition-colors"
            >
              <Mic className="w-4 h-4" aria-hidden="true" />
              <span>{t.sections.askVoiceButton}</span>
            </button>
          </div>
        </div>

        <p className="text-base text-slate-700 leading-relaxed bg-emerald-50/70 border border-teal-100 rounded-2xl p-4">
          {activeGuide.intro[language]}
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {activeGuide.sections.map((section, idx) => (
            <div key={idx} className="space-y-3">
              <h3 className="text-lg font-bold text-teal-950">
                {section.heading[language]}
              </h3>
              <ul className="space-y-2.5">
                {section.bullets[language].map((bullet, bIdx) => (
                  <li
                    key={bIdx}
                    className="flex items-start gap-3 text-base text-slate-800 leading-relaxed"
                  >
                    <span
                      aria-hidden="true"
                      className="mt-1.5 w-2 h-2 rounded-full bg-teal-600 shrink-0"
                    />
                    <span>{bullet}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Interactive Hospital Bill Term Explorer (shown especially inside Bill guide, or helpful reference) */}
        {activeGuide.id === 'bill' && (
          <div className="pt-6 border-t border-teal-100 space-y-4">
            <div>
              <h3 className="text-lg sm:text-xl font-bold text-teal-950">
                {t.sections.billExplorerTitle}
              </h3>
              <p className="text-sm text-slate-600 mt-1">
                {t.sections.billExplorerSubtitle}
              </p>
            </div>

            <div className="flex flex-wrap gap-2">
              {BILL_TERMS.map((bt) => {
                const selected = bt.id === selectedBillTermId;
                return (
                  <button
                    key={bt.id}
                    type="button"
                    onClick={() => {
                      setSelectedBillTermId(bt.id);
                      if (isTtsSupported) {
                        onSpeakText(
                          `${bt.term[language]}. ${bt.simpleMeaning[language]}. ${t.sections.billCheckLabel} ${bt.whatToCheck[language]}`,
                          `bill-term-${bt.id}`
                        );
                      }
                    }}
                    className={`min-h-[44px] px-4 py-2 rounded-xl text-sm font-semibold cursor-pointer border transition-colors ${
                      selected
                        ? 'bg-teal-700 text-white border-teal-700'
                        : 'bg-emerald-50 text-teal-950 border-teal-200 hover:bg-emerald-100'
                    }`}
                  >
                    {bt.term[language]}
                  </button>
                );
              })}
            </div>

            <div className="bg-emerald-50/70 border border-teal-200 rounded-2xl p-5 space-y-2.5">
              <div className="flex items-center justify-between gap-3">
                <h4 className="text-lg font-bold text-teal-950">
                  {activeBillTerm.term[language]}
                </h4>
                {isTtsSupported && (
                  <button
                    type="button"
                    onClick={() => {
                      const id = `bill-term-${activeBillTerm.id}`;
                      if (speakingId === id) {
                        onStopSpeaking();
                      } else {
                        onSpeakText(
                          `${activeBillTerm.term[language]}. ${activeBillTerm.simpleMeaning[language]}. ${t.sections.billCheckLabel} ${activeBillTerm.whatToCheck[language]}`,
                          id
                        );
                      }
                    }}
                    className="min-h-[40px] px-3.5 py-1.5 rounded-xl text-sm font-semibold bg-white border border-teal-200 text-teal-900 hover:bg-emerald-100 flex items-center gap-1.5 cursor-pointer"
                  >
                    <Volume2 className="w-4 h-4" aria-hidden="true" />
                    <span>{t.voiceControls.listenAnswer}</span>
                  </button>
                )}
              </div>
              <p className="text-base text-slate-800 leading-relaxed">
                {activeBillTerm.simpleMeaning[language]}
              </p>
              <p className="text-sm sm:text-base text-teal-900 leading-relaxed">
                <span className="font-bold">{t.sections.billCheckLabel} </span>
                {activeBillTerm.whatToCheck[language]}
              </p>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
