import { FormEvent, useEffect, useRef, useState } from 'react';
import {
  ArrowRight,
  Mic,
  MicOff,
  RotateCcw,
  Send,
  Square,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { ChatMessage, Language } from '../types/sahaay';
import { UI_STRINGS } from '../data/translations';
import { SAMPLE_QUESTIONS } from '../data/knowledgeBase';
import { MicErrorType } from '../hooks/useSpeech';

interface VoiceHomeProps {
  language: Language;
  messages: ChatMessage[];
  autoSpeak: boolean;
  onToggleAutoSpeak: () => void;
  onAskQuestion: (query: string) => void;
  onClearConversation: () => void;
  isRecognitionSupported: boolean;
  isTtsSupported: boolean;
  isListening: boolean;
  interimTranscript: string;
  micError: MicErrorType;
  speakingId: string | null;
  onStartListening: () => void;
  onStopListening: () => void;
  onSpeakText: (text: string, id: string) => void;
  onStopSpeaking: () => void;
}

export function VoiceHome({
  language,
  messages,
  autoSpeak,
  onToggleAutoSpeak,
  onAskQuestion,
  onClearConversation,
  isRecognitionSupported,
  isTtsSupported,
  isListening,
  interimTranscript,
  micError,
  speakingId,
  onStartListening,
  onStopListening,
  onSpeakText,
  onStopSpeaking,
}: VoiceHomeProps) {
  const [inputText, setInputText] = useState('');
  const latestMsgRef = useRef<HTMLDivElement | null>(null);
  const inputRef = useRef<HTMLInputElement | null>(null);
  const t = UI_STRINGS[language];

  useEffect(() => {
    if (messages.length > 0 && latestMsgRef.current) {
      latestMsgRef.current.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
  }, [messages.length]);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const trimmed = inputText.trim();
    if (!trimmed) return;
    onAskQuestion(trimmed);
    setInputText('');
  };

  const handleMicPress = () => {
    if (!isRecognitionSupported) {
      inputRef.current?.focus();
      return;
    }
    if (isListening) {
      onStopListening();
    } else {
      onStartListening();
    }
  };

  const buildSpeakableAnswer = (msg: ChatMessage) => {
    const parts = [msg.title, msg.text];
    if (msg.points && msg.points.length > 0) {
      parts.push(...msg.points);
    }
    if (msg.note) {
      parts.push(msg.note);
    }
    return parts.filter(Boolean).join('. ');
  };

  return (
    <section className="max-w-6xl mx-auto px-4 sm:px-6 pt-6 sm:pt-8">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-start">
        {/* Left Column: Voice Hero, Microphone Button & Text Input */}
        <div className="lg:col-span-5 bg-white border border-teal-200/80 rounded-3xl p-6 sm:p-8 shadow-xs">
          <div className="space-y-2.5 text-center lg:text-left">
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-teal-950 leading-tight">
              {t.heroTitle}
            </h1>
            <p className="text-base text-slate-600 leading-relaxed">
              {t.heroSubtitle}
            </p>
          </div>

          {/* Large Microphone Action Area */}
          <div className="mt-7 flex flex-col items-center">
            <button
              type="button"
              onClick={handleMicPress}
              aria-pressed={isListening}
              aria-label={isListening ? t.mic.tapToStop : t.mic.tapToSpeak}
              className={`relative w-32 h-32 sm:w-36 sm:h-36 rounded-full flex flex-col items-center justify-center gap-1.5 cursor-pointer transition-transform active:scale-95 shadow-md ${
                isListening
                  ? 'bg-emerald-700 text-white ring-8 ring-emerald-200'
                  : isRecognitionSupported
                  ? 'bg-teal-700 hover:bg-teal-800 text-white ring-8 ring-emerald-50'
                  : 'bg-slate-200 text-slate-700 ring-8 ring-slate-100'
              }`}
            >
              {isListening ? (
                <Square className="w-10 h-10 fill-current" aria-hidden="true" />
              ) : isRecognitionSupported ? (
                <Mic className="w-12 h-12" strokeWidth={2.2} aria-hidden="true" />
              ) : (
                <MicOff className="w-10 h-10" aria-hidden="true" />
              )}
            </button>

            <p className="mt-4 text-base font-bold text-teal-950 text-center">
              {isListening ? t.mic.listening : t.mic.tapToSpeak}
            </p>

            {isListening && (
              <button
                type="button"
                onClick={onStopListening}
                className="mt-2 min-h-[44px] px-4 py-2 text-sm font-semibold text-teal-900 bg-emerald-100 hover:bg-emerald-200 rounded-xl cursor-pointer transition-colors"
              >
                {t.mic.tapToStop}
              </button>
            )}

            {/* Real-time interim speech transcript */}
            {interimTranscript && (
              <div
                aria-live="polite"
                className="mt-3 w-full bg-emerald-50 border border-teal-200 rounded-2xl px-4 py-3 text-sm text-teal-950"
              >
                <span className="font-semibold">{t.mic.heardPrefix} </span>
                <span>“{interimTranscript}”</span>
              </div>
            )}

            {/* Speech recognition unavailable fallback notice */}
            {!isRecognitionSupported && (
              <div className="mt-4 w-full bg-emerald-50 border border-teal-200 rounded-2xl p-4 text-left">
                <p className="text-sm font-bold text-teal-950">
                  {t.mic.unavailableTitle}
                </p>
                <p className="mt-1 text-sm text-slate-700 leading-relaxed">
                  {t.mic.unavailableDesc}
                </p>
              </div>
            )}

            {/* Mic error message */}
            {micError && (
              <div
                role="alert"
                className="mt-4 w-full bg-amber-50 border border-amber-200 rounded-2xl p-4 text-sm text-amber-950 text-left"
              >
                {micError === 'permission'
                  ? t.mic.permissionError
                  : micError === 'no-speech'
                  ? t.mic.noSpeechError
                  : t.mic.unavailableDesc}
              </div>
            )}
          </div>

          {/* Text Input Alternative / Companion */}
          <form onSubmit={handleSubmit} className="mt-6 space-y-3">
            <label
              htmlFor="sahaay-question-input"
              className="block text-sm font-semibold text-teal-950"
            >
              {t.input.orTypeHint}
            </label>
            <div className="flex flex-col sm:flex-row gap-2.5">
              <input
                ref={inputRef}
                id="sahaay-question-input"
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder={t.input.placeholder}
                className="flex-1 min-h-[52px] px-4 py-3 text-base bg-emerald-50/50 border border-teal-200 rounded-2xl text-slate-900 placeholder:text-slate-500 focus:bg-white transition-colors"
              />
              <button
                type="submit"
                disabled={!inputText.trim()}
                className="min-h-[52px] px-6 py-3 bg-teal-700 hover:bg-teal-800 disabled:bg-slate-200 disabled:text-slate-500 text-white font-bold text-base rounded-2xl flex items-center justify-center gap-2 shrink-0 cursor-pointer transition-colors"
              >
                <span>{t.input.sendButton}</span>
                <Send className="w-4 h-4" aria-hidden="true" />
              </button>
            </div>
          </form>

          {/* Auto-speak toggle & Clear button */}
          <div className="mt-5 pt-5 border-t border-teal-100 flex flex-wrap items-center justify-between gap-3">
            {isTtsSupported && (
              <button
                type="button"
                onClick={onToggleAutoSpeak}
                aria-pressed={autoSpeak}
                className={`min-h-[44px] px-3.5 py-2 rounded-xl text-sm font-semibold flex items-center gap-2 cursor-pointer border transition-colors ${
                  autoSpeak
                    ? 'bg-emerald-50 border-teal-300 text-teal-900'
                    : 'bg-white border-slate-200 text-slate-600'
                }`}
              >
                {autoSpeak ? (
                  <Volume2 className="w-4 h-4 text-teal-700" aria-hidden="true" />
                ) : (
                  <VolumeX className="w-4 h-4 text-slate-500" aria-hidden="true" />
                )}
                <span>{t.voiceControls.autoSpeak}</span>
              </button>
            )}

            {messages.length > 0 && (
              <button
                type="button"
                onClick={onClearConversation}
                className="min-h-[44px] px-4 py-2 rounded-xl text-sm font-semibold bg-white border border-teal-300 text-teal-900 hover:bg-emerald-50 flex items-center gap-2 cursor-pointer transition-colors"
              >
                <RotateCcw className="w-4 h-4" aria-hidden="true" />
                <span>{t.voiceControls.clearChat}</span>
              </button>
            )}
          </div>
        </div>

        {/* Right Column: Active Conversation & Sample Question Cards */}
        <div className="lg:col-span-7 space-y-6">
          {/* Active Conversation Thread */}
          {messages.length > 0 && (
            <div className="space-y-4">
              <div className="flex items-center justify-between gap-4">
                <h2 className="text-lg sm:text-xl font-bold text-teal-950">
                  {t.sections.conversationTitle}
                </h2>
                <button
                  type="button"
                  onClick={onClearConversation}
                  className="min-h-[44px] px-3.5 py-2 text-sm font-semibold text-teal-800 hover:bg-emerald-50 rounded-xl flex items-center gap-1.5 cursor-pointer transition-colors"
                >
                  <RotateCcw className="w-4 h-4" aria-hidden="true" />
                  <span>{t.voiceControls.clearChat}</span>
                </button>
              </div>

              <div className="space-y-4">
                {messages.map((msg, idx) => {
                  const isLast = idx === messages.length - 1;
                  const isSpeakingThis = speakingId === msg.id;

                  if (msg.role === 'user') {
                    return (
                      <div
                        key={msg.id}
                        className="bg-teal-700 text-white rounded-2xl p-4 sm:p-5 ml-4 sm:ml-10"
                      >
                        <div className="text-xs font-medium text-emerald-100 mb-1">
                          {t.labels.youAsked} · {msg.timestamp}
                        </div>
                        <p className="text-base sm:text-lg font-semibold leading-snug">
                          {msg.text}
                        </p>
                      </div>
                    );
                  }

                  return (
                    <div
                      key={msg.id}
                      ref={isLast ? latestMsgRef : undefined}
                      className={`rounded-3xl p-5 sm:p-6 border ${
                        msg.isSafetyNotice
                          ? 'bg-amber-50/80 border-amber-200'
                          : 'bg-white border-teal-200'
                      }`}
                    >
                      <div className="flex flex-wrap items-center justify-between gap-3 mb-3">
                        <span className="text-xs font-semibold text-teal-800">
                          {t.labels.assistantReply} · {msg.timestamp}
                        </span>

                        {isTtsSupported && (
                          <button
                            type="button"
                            onClick={() =>
                              isSpeakingThis
                                ? onStopSpeaking()
                                : onSpeakText(buildSpeakableAnswer(msg), msg.id)
                            }
                            className={`min-h-[44px] px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-2 cursor-pointer transition-colors ${
                              isSpeakingThis
                                ? 'bg-emerald-700 text-white'
                                : 'bg-emerald-50 text-teal-900 hover:bg-emerald-100 border border-teal-200'
                            }`}
                          >
                            {isSpeakingThis ? (
                              <>
                                <Square className="w-4 h-4 fill-current" aria-hidden="true" />
                                <span>{t.voiceControls.stopSpeaking}</span>
                              </>
                            ) : (
                              <>
                                <Volume2 className="w-4 h-4" aria-hidden="true" />
                                <span>{t.voiceControls.listenAnswer}</span>
                              </>
                            )}
                          </button>
                        )}
                      </div>

                      {msg.title && (
                        <h3 className="text-lg sm:text-xl font-bold text-teal-950 mb-2">
                          {msg.title}
                        </h3>
                      )}

                      <p className="text-base text-slate-700 leading-relaxed">
                        {msg.text}
                      </p>

                      {msg.points && msg.points.length > 0 && (
                        <ul className="mt-4 space-y-2.5">
                          {msg.points.map((point, pIdx) => (
                            <li
                              key={pIdx}
                              className="flex items-start gap-3 text-base text-slate-800 leading-relaxed"
                            >
                              <span
                                aria-hidden="true"
                                className="mt-1 w-6 h-6 rounded-full bg-emerald-100 text-teal-900 text-xs font-bold flex items-center justify-center shrink-0 tabular-nums"
                              >
                                {pIdx + 1}
                              </span>
                              <span>{point}</span>
                            </li>
                          ))}
                        </ul>
                      )}

                      {msg.note && (
                        <div className="mt-4 bg-emerald-50 border border-teal-200/70 rounded-2xl p-4 text-sm text-teal-950 leading-relaxed">
                          <span className="font-bold">{t.labels.importantNote}: </span>
                          {msg.note}
                        </div>
                      )}

                      {/* Follow-up Question Buttons */}
                      {isLast && msg.followUps && msg.followUps.length > 0 && (
                        <div className="mt-5 pt-4 border-t border-teal-100">
                          <p className="text-sm font-bold text-teal-900 mb-2.5">
                            {t.sections.followUpTitle}
                          </p>
                          <div className="flex flex-col sm:flex-row sm:flex-wrap gap-2.5">
                            {msg.followUps.map((fu) => (
                              <button
                                key={fu.id}
                                type="button"
                                onClick={() => onAskQuestion(fu.query[language])}
                                className="min-h-[46px] px-4 py-2.5 text-left text-sm font-semibold bg-emerald-50 hover:bg-emerald-100 text-teal-950 border border-teal-200 rounded-2xl flex items-center justify-between gap-2 cursor-pointer transition-colors"
                              >
                                <span>{fu.label[language]}</span>
                                <ArrowRight className="w-4 h-4 shrink-0 text-teal-700" aria-hidden="true" />
                              </button>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Sample Questions Grid */}
          <div className="bg-white border border-teal-200/80 rounded-3xl p-5 sm:p-6">
            <div className="mb-4">
              <h2 className="text-lg sm:text-xl font-bold text-teal-950">
                {t.sections.sampleQuestionsTitle}
              </h2>
              <p className="mt-1 text-sm text-slate-600">
                {t.sections.sampleQuestionsSubtitle}
              </p>
            </div>

            <div className="grid grid-cols-1 gap-3">
              {SAMPLE_QUESTIONS.map((sq, index) => (
                <button
                  key={sq.id}
                  type="button"
                  onClick={() => onAskQuestion(sq.question[language])}
                  className="w-full min-h-[56px] p-4 text-left bg-emerald-50/70 hover:bg-emerald-100/80 border border-teal-200/80 rounded-2xl flex items-center justify-between gap-3 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-3.5">
                    <span
                      aria-hidden="true"
                      className="w-8 h-8 rounded-xl bg-teal-700 text-white text-sm font-bold flex items-center justify-center shrink-0 tabular-nums"
                    >
                      {index + 1}
                    </span>
                    <span className="text-base font-semibold text-teal-950 leading-snug">
                      {sq.question[language]}
                    </span>
                  </div>
                  <ArrowRight className="w-5 h-5 text-teal-700 shrink-0" aria-hidden="true" />
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
