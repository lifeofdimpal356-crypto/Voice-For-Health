import {
  BillTerm,
  ChecklistItem,
  FaqItem,
  KnowledgeIntent,
  SampleQuestion,
  TopicGuide,
} from '../types/sahaay';

export const SAMPLE_QUESTIONS: SampleQuestion[] = [
  {
    id: 'sample-operation',
    topic: 'operation',
    question: {
      en: 'What should I ask before an operation?',
      hi: 'ऑपरेशन से पहले डॉक्टर से क्या पूछना चाहिए?',
      gu: 'ઓપરેશન પહેલાં ડૉક્ટરને શું પૂછવું જોઈએ?',
    },
  },
  {
    id: 'sample-bill',
    topic: 'bill',
    question: {
      en: 'How can I understand my hospital bill?',
      hi: 'मैं अपने अस्पताल के बिल को कैसे समझूँ?',
      gu: 'હું મારા હોસ્પિટલના બિલને કેવી રીતે સમજું?',
    },
  },
  {
    id: 'sample-schemes',
    topic: 'schemes',
    question: {
      en: 'Which government healthcare schemes may help me?',
      hi: 'कौन-सी सरकारी स्वास्थ्य योजनाएँ मेरी मदद कर सकती हैं?',
      gu: 'કઈ સરકારી આરોગ્ય યોજનાઓ મને મદદ કરી શકે છે?',
    },
  },
  {
    id: 'sample-rights',
    topic: 'rights',
    question: {
      en: 'What are my rights as a patient?',
      hi: 'मरीज़ के रूप में मेरे क्या अधिकार हैं?',
      gu: 'દર્દી તરીકે મારા કયા અધિકારો છે?',
    },
  },
  {
    id: 'sample-documents',
    topic: 'admission',
    question: {
      en: 'What documents are needed for hospital admission?',
      hi: 'अस्पताल में भर्ती होने के लिए कौन-से कागज़ात चाहिए?',
      gu: 'હોસ્પિટલમાં દાખલ થવા માટે કયા કાગળોની જરૂર પડે છે?',
    },
  },
];

export const KNOWLEDGE_INTENTS: KnowledgeIntent[] = [
  {
    id: 'medical-safety-guardrail',
    category: 'safety',
    keywords: [
      'diagnose',
      'diagnosis',
      'which medicine',
      'what medicine',
      'tablet',
      'pill',
      'syrup',
      'antibiotic',
      'dose',
      'dosage',
      'prescribe',
      'prescription',
      'fever',
      'cough',
      'chest pain',
      'stomach pain',
      'headache',
      'infection',
      'diabetes',
      'blood pressure',
      'dawai',
      'dava',
      'goli',
      'bukhar',
      'dard',
      'bimari',
      'ilaj batao',
      'दवा',
      'दवाई',
      'गोली',
      'बुखार',
      'दर्द',
      'बीमारी',
      'इलाज बताओ',
      'દવા',
      'ગોળી',
      'તાવ',
      'દુખાવો',
      'રોગ',
      'નિદાન',
    ],
    title: {
      en: 'Please Consult a Doctor for Medical Advice',
      hi: 'दवा या बीमारी की जांच के लिए डॉक्टर से मिलें',
      gu: 'દવા અથવા રોગની તપાસ માટે ડૉક્ટરને મળો',
    },
    summary: {
      en: 'I cannot diagnose illnesses or recommend any medicines or doses. Only a qualified doctor who checks the patient in person can give safe medical advice.',
      hi: 'मैं किसी बीमारी की जांच नहीं कर सकता और न ही कोई दवा या खुराक बता सकता हूँ। केवल एक योग्य डॉक्टर ही मरीज़ को देखकर सही सलाह दे सकते हैं।',
      gu: 'હું કોઈ રોગનું નિદાન કરી શકતો નથી કે કોઈ દવા અથવા ડોઝ સૂચવી શકતો નથી. ફક્ત લાયક ડૉક્ટર જ દર્દીને તપાસીને સુરક્ષિત સલાહ આપી શકે છે.',
    },
    points: {
      en: [
        'Visit your nearest Primary Health Centre (PHC), government hospital, or trusted doctor.',
        'If there is severe pain, trouble breathing, heavy bleeding, or sudden weakness, call 108 (Ambulance) right away.',
        'For general non-emergency guidance in many states, you can call the 104 Health Helpline.',
        'I can help you prepare questions to ask the doctor, understand hospital bills, or check admission documents.',
      ],
      hi: [
        'अपने नजदीकी प्राथमिक स्वास्थ्य केंद्र (PHC), सरकारी अस्पताल या डॉक्टर के पास जाएँ।',
        'तेज़ दर्द, सांस लेने में तकलीफ, ज़्यादा खून बहने या अचानक कमज़ोरी पर तुरंत 108 (एम्बुलेंस) बुलाएँ।',
        'कई राज्यों में सामान्य स्वास्थ्य सहायता के लिए 104 हेल्पलाइन पर कॉल किया जा सकता है।',
        'मैं आपको डॉक्टर से पूछने वाले सवाल, अस्पताल का बिल और भर्ती के कागज़ात समझने में मदद कर सकता हूँ।',
      ],
      gu: [
        'તમારા નજીકના પ્રાથમિક આરોગ્ય કેન્દ્ર (PHC), સરકારી હોસ્પિટલ અથવા ડૉક્ટર પાસે જાઓ.',
        'વધુ દુખાવો, શ્વાસ લેવામાં તકલીફ, વધુ લોહી નીકળવું કે અચાનક નબળાઈ હોય તો તરત 108 (એમ્બ્યુલન્સ) બોલાવો.',
        'ઘણા રાજ્યોમાં સામાન્ય આરોગ્ય માર્ગદર્શન માટે 104 હેલ્પલાઇન પર કૉલ કરી શકાય છે.',
        'હું તમને ડૉક્ટરને પૂછવાના પ્રશ્નો, હોસ્પિટલ બિલ અને દાખલ થવાના કાગળો સમજવામાં મદદ કરી શકું છું.',
      ],
    },
    note: {
      en: 'Never take medicines suggested by strangers or online messages without a doctor checking the patient.',
      hi: 'डॉक्टर की सलाह के बिना किसी के कहने पर या इंटरनेट देखकर कोई भी दवा न लें।',
      gu: 'ડૉક્ટરની સલાહ વિના કોઈના કહેવાથી કે ઇન્ટરનેટ જોઈને કોઈ દવા ન લો.',
    },
    followUps: [
      {
        id: 'fu-safety-1',
        label: {
          en: 'What should I ask before an operation?',
          hi: 'ऑपरेशन से पहले क्या पूछें?',
          gu: 'ઓપરેશન પહેલાં શું પૂછવું?',
        },
        query: {
          en: 'What should I ask before an operation?',
          hi: 'ऑपरेशन से पहले डॉक्टर से क्या पूछना चाहिए?',
          gu: 'ઓપરેશન પહેલાં ડૉક્ટરને શું પૂછવું જોઈએ?',
        },
      },
      {
        id: 'fu-safety-2',
        label: {
          en: 'What documents are needed for admission?',
          hi: 'भर्ती के लिए कौन-से कागज़ात चाहिए?',
          gu: 'દાખલ થવા કયા કાગળો જોઈએ?',
        },
        query: {
          en: 'What documents are needed for hospital admission?',
          hi: 'अस्पताल में भर्ती होने के लिए कौन-से कागज़ात चाहिए?',
          gu: 'હોસ્પિટલમાં દાખલ થવા માટે કયા કાગળોની જરૂર પડે છે?',
        },
      },
    ],
  },
  {
    id: 'before-operation',
    category: 'operation',
    keywords: [
      'operation',
      'surgery',
      'surgical',
      'before operation',
      'ask doctor',
      'anesthesia',
      'operasyon',
      'opration',
      'se pehle',
      'kya puchna',
      'ऑपरेशन',
      'सर्जरी',
      'शस्त्रक्रिया',
      'ઓપરેશન',
      'સર્જરી',
      'શસ્ત્રક્રિયા',
    ],
    title: {
      en: 'Questions to Ask Before an Operation',
      hi: 'ऑपरेशन से पहले डॉक्टर से पूछने वाले ज़रूरी सवाल',
      gu: 'ઓપરેશન પહેલાં ડૉક્ટરને પૂછવાના મહત્વના પ્રશ્નો',
    },
    summary: {
      en: 'Before giving consent for any operation, you and your family have the right to clear answers in simple words you understand.',
      hi: 'किसी भी ऑपरेशन के कागज़ पर हस्ताक्षर करने से पहले आपको और आपके परिवार को सरल भाषा में पूरी जानकारी पाने का हक है।',
      gu: 'કોઈપણ ઓપરેશન માટે સહી કરતાં પહેલાં તમને અને તમારા પરિવારને સરળ ભાષામાં પૂરી માહિતી મેળવવાનો અધિકાર છે.',
    },
    points: {
      en: [
        'Why is this operation needed, and are there any non-surgical options?',
        'How long will the patient stay in the hospital, and how many days for recovery?',
        'What are the common risks, and what type of anesthesia (numbing) will be used?',
        'Can you give a written cost estimate covering surgeon, room, anesthesia, tests, and medicines?',
        'Does this hospital accept government health schemes like Ayushman Bharat (PM-JAY) or state cards?',
      ],
      hi: [
        'यह ऑपरेशन क्यों ज़रूरी है, और क्या बिना ऑपरेशन के कोई दूसरा विकल्प है?',
        'मरीज़ को अस्पताल में कितने दिन रहना होगा और पूरी तरह ठीक होने में कितना समय लगेगा?',
        'इस ऑपरेशन के मुख्य जोखिम क्या हैं और बेहोशी (एनेस्थीसिया) किस तरह दी जाएगी?',
        'क्या आप डॉक्टर फीस, कमरा, जांच, दवा और ऑपरेशन का लिखित अनुमानित खर्च दे सकते हैं?',
        'क्या इस अस्पताल में आयुष्मान भारत या राज्य की स्वास्थ्य योजना कार्ड स्वीकार होता है?',
      ],
      gu: [
        'આ ઓપરેશન કેમ જરૂરી છે, અને શું ઓપરેશન વગર બીજો કોઈ વિકલ્પ છે?',
        'દર્દીને હોસ્પિટલમાં કેટલા દિવસ રહેવું પડશે અને સાજા થવામાં કેટલો સમય લાગશે?',
        'આ ઓપરેશનના મુખ્ય જોખમો શું છે અને બેભાન (એનેસ્થેસિયા) કેવી રીતે કરાશે?',
        'શું તમે ડૉક્ટર ફી, રૂમ, રિપોર્ટ, દવા અને ઓપરેશનનો લેખિત અંદાજિત ખર્ચ આપી શકો છો?',
        'શું આ હોસ્પિટલમાં આયુષ્માન ભારત કે રાજ્યની આરોગ્ય યોજનાનું કાર્ડ ચાલે છે?',
      ],
    },
    note: {
      en: 'Do not hesitate to bring a trusted family member to listen with you, or ask the nurse to explain in your language.',
      hi: 'बात सुनने के लिए किसी भरोसेमंद परिजन को साथ रखें और ज़रूरत हो तो अपनी भाषा में समझाने को कहें।',
      gu: 'સાંભળવા માટે પરિવારના વિશ્વાસુ સભ્યને સાથે રાખો અને જરૂર હોય તો તમારી ભાષામાં સમજાવવા કહો.',
    },
    followUps: [
      {
        id: 'fu-op-cost',
        label: {
          en: 'How to ask for an operation cost estimate?',
          hi: 'ऑपरेशन खर्च का लिखित अनुमान कैसे मांगें?',
          gu: 'ઓપરેશન ખર્ચનો લેખિત અંદાજ કેવી રીતે માંગવો?',
        },
        query: {
          en: 'How do I ask for an operation cost estimate?',
          hi: 'ऑपरेशन के खर्च का अनुमान कैसे पूछें?',
          gu: 'ઓપરેશનના ખર્ચનો અંદાજ કેવી રીતે પૂછવો?',
        },
      },
      {
        id: 'fu-op-schemes',
        label: {
          en: 'Which government schemes may help?',
          hi: 'कौन-सी सरकारी योजनाएँ मदद कर सकती हैं?',
          gu: 'કઈ સરકારી યોજનાઓ મદદ કરી શકે?',
        },
        query: {
          en: 'Which government healthcare schemes may help me?',
          hi: 'कौन-सी सरकारी स्वास्थ्य योजनाएँ मेरी मदद कर सकती हैं?',
          gu: 'કઈ સરકારી આરોગ્ય યોજનાઓ મને મદદ કરી શકે છે?',
        },
      },
      {
        id: 'fu-op-consent',
        label: {
          en: 'What is a consent form?',
          hi: 'सहमति फ़ॉर्म (Consent Form) क्या होता है?',
          gu: 'સંમતિ ફોર્મ (Consent Form) શું હોય છે?',
        },
        query: {
          en: 'What should I check before signing a hospital consent form?',
          hi: 'सहमति फ़ॉर्म पर साइन करने से पहले क्या जांचें?',
          gu: 'સંમતિ ફોર્મ પર સહી કરતાં પહેલાં શું તપાસવું?',
        },
      },
    ],
  },
  {
    id: 'operation-cost-estimate',
    category: 'operation',
    keywords: [
      'cost estimate',
      'surgery cost',
      'operation cost',
      'package',
      'expensive',
      'kitna kharcha',
      'kharcha',
      'estimate',
      'kharch',
      'खर्च',
      'कीमत',
      'अनुमान',
      'ખર્ચ',
      'અંદાજ',
      'પૈસા',
    ],
    title: {
      en: 'Asking About Operation & Hospital Costs',
      hi: 'ऑपरेशन और अस्पताल के खर्च को पहले समझना',
      gu: 'ઓપરેશન અને હોસ્પિટલના ખર્ચને પહેલેથી સમજવો',
    },
    summary: {
      en: 'Hospital costs depend on the city, hospital type (government vs private), ward type, and medicines needed. Always ask the billing desk for a written estimate before admission.',
      hi: 'अस्पताल का खर्च शहर, सरकारी या प्राइवेट अस्पताल, कमरे के प्रकार और दवाइयों पर निर्भर करता है। भर्ती से पहले बिलिंग डेस्क से लिखित अनुमान ज़रूर मांगें।',
      gu: 'હોસ્પિટલનો ખર્ચ શહેર, સરકારી કે ખાનગી હોસ્પિટલ, રૂમના પ્રકાર અને દવાઓ પર આધાર રાખે છે. દાખલ થતાં પહેલાં બિલિંગ ડેस्क પાસેથી લેખિત અંદાજ અવશ્ય માંગો.',
    },
    points: {
      en: [
        'Ask if there is a fixed "package" price or separate charges for every item.',
        'Check if the estimate includes surgeon fee, OT charges, anesthesia, bed rent, lab tests, and implants.',
        'Ask how much daily room rent differs between General Ward, Semi-Private, and Private rooms.',
        'Ask if you can buy medicines from a Jan Aushadhi Kendra (generic medicine store) if allowed.',
        'Visit the Aarogya Mitra desk at the hospital to check if your family qualifies for free/cashless scheme care.',
      ],
      hi: [
        'पूछें कि क्या कोई तय "पैकेज" है या हर चीज़ का अलग-अलग शुल्क लगेगा।',
        'जानें कि अनुमान में सर्जन फीस, ऑपरेशन थिएटर, बेहोशी, बेड किराया, जांच और इम्प्लांट शामिल हैं या नहीं।',
        'जनरल वार्ड, सेमी-प्राइवेट और प्राइवेट कमरे के रोज़ाना किराये का अंतर पूछें।',
        'पूछें कि क्या आप जन औषधि केंद्र से सस्ती जेनेरिक दवाइयाँ ला सकते हैं।',
        'अस्पताल के आरोग्य मित्र डेस्क पर जाकर पता करें कि सरकारी योजना से मुफ्त या कैशलेस इलाज मिल सकता है या नहीं।',
      ],
      gu: [
        'પૂછો કે શું કોઈ નક્કી "પૅકેજ" છે કે દરેક વસ્તુનો અલગ ચાર્જ લાગશે.',
        'તપાસો કે અંદાજમાં સર્જન ફી, ઓપરેશન થિયેટર, બેભાન ચાર્જ, બેડ ભાડું અને રિપોર્ટ સામેલ છે કે નહીં.',
        'જનરલ વોર્ડ, સેમી-પ્રાઇવેટ અને પ્રાઇવેટ રૂમના રોજના ભાડાનો તફાવત પૂછો.',
        'પૂછો કે શું તમે જન ઔષધિ કેન્દ્રમાંથી સસ્તી જેનેરિક દવાઓ લાવી શકો છો.',
        'હોસ્પિટલમાં આરોગ્ય મિત્ર ડેસ્ક પર જઈને સરકારી યોજના હેઠળ મફત/કેશલેસ મદદ મળે છે કે નહીં તે તપાસો.',
      ],
    },
    note: {
      en: 'Costs shown here are general guidance only — Sahaay Voice cannot quote or guarantee actual hospital prices.',
      hi: 'यह केवल सामान्य जानकारी है — सहाय वॉइस किसी अस्पताल का पक्का खर्च तय या गारंटी नहीं कर सकता।',
      gu: 'આ ફક્ત સામાન્ય માહિતી છે — સહાય વૉઇસ કોઈ હોસ્પિટલનો ચોક્કસ ખર્ચ નક્કી કે ખાતરી કરી શકતું નથી.',
    },
    followUps: [
      {
        id: 'fu-cost-bill',
        label: {
          en: 'How can I understand my hospital bill?',
          hi: 'अस्पताल का बिल कैसे समझें?',
          gu: 'હોસ્પિટલનું બિલ કેવી રીતે સમજવું?',
        },
        query: {
          en: 'How can I understand my hospital bill?',
          hi: 'मैं अपने अस्पताल के बिल को कैसे समझूँ?',
          gu: 'હું મારા હોસ્પિટલના બિલને કેવી રીતે સમજું?',
        },
      },
      {
        id: 'fu-cost-scheme',
        label: {
          en: 'Which government schemes may help?',
          hi: 'सरकारी योजनाएँ कौन-सी हैं?',
          gu: 'સરકારી યોજનાઓ કઈ છે?',
        },
        query: {
          en: 'Which government healthcare schemes may help me?',
          hi: 'कौन-सी सरकारी स्वास्थ्य योजनाएँ मेरी मदद कर सकती हैं?',
          gu: 'કઈ સરકારી આરોગ્ય યોજનાઓ મને મદદ કરી શકે છે?',
        },
      },
    ],
  },
  {
    id: 'hospital-bill',
    category: 'bill',
    keywords: [
      'bill',
      'charges',
      'invoice',
      'itemized',
      'receipt',
      'overcharge',
      'payment',
      'deposit',
      'samjhao',
      'hisab',
      'बिल',
      'खर्चा',
      'रसीद',
      'शुल्क',
      'બિલ',
      'રસીદ',
      'ચાર્જ',
      'હિસાબ',
    ],
    title: {
      en: 'How to Understand Your Hospital Bill',
      hi: 'अपने अस्पताल के बिल को आसानी से समझें',
      gu: 'તમારા હોસ્પિટલના બિલને સરળતાથી સમજો',
    },
    summary: {
      en: 'Never pay a lump-sum bill without seeing the detailed list. Every patient has the right to ask for an itemized (line-by-line) bill in simple words.',
      hi: 'बिना पूरा विवरण देखे एकमुश्त बिल न भरें। हर मरीज़ को एक-एक खर्च की अलग सूची (Itemized Bill) मांगने का अधिकार है।',
      gu: 'પૂરી વિગત જોયા વગર એકસાથે બિલ ન ચૂકવો. દરેક દર્દીને દરેક ખર્ચની અલગ યાદી (Itemized Bill) માંગવાનો અધિકાર છે.',
    },
    points: {
      en: [
        'Ask for an "Itemized Bill" showing each medicine, lab test, and room day separately.',
        'Check admission and discharge dates so you are not billed for extra days.',
        'Verify your advance deposits (money already paid) are subtracted from the total.',
        'Look at "Consumables" (gloves, syringes, bandages) and ask if any unused items were returned.',
        'If a charge looks confusing or repeated twice, politely ask the billing counter to explain before paying.',
      ],
      hi: [
        'बिलिंग काउंटर से "विस्तृत बिल (Itemized Bill)" मांगें जिसमें हर दवा, जांच और कमरे का दिन अलग लिखा हो।',
        'भर्ती और छुट्टी (Discharge) की तारीख जांचें ताकि अतिरिक्त दिनों का पैसा न जुड़े।',
        'जांचें कि आपने पहले जो जमा राशि (Advance Deposit) दी थी, वह कुल बिल में से घटाई गई है या नहीं।',
        '"कंज्यूमेबल्स" (दस्ताने, सिरिंज, पट्टी) में देखें कि बची हुई बिना इस्तेमाल चीज़ें वापस हुईं या नहीं।',
        'कोई शुल्क दो बार जुड़ा दिखे या समझ न आए, तो भुगतान से पहले शांत मन से पूछें।',
      ],
      gu: [
        'બિલિંગ કાઉન્ટર પાસેથી "વિગતવાર બિલ (Itemized Bill)" માંગો જેમાં દરેક દવા, રિપોર્ટ અને રૂમનો દિવસ અલગ લખેલો હોય.',
        'દાખલ અને રજા (Discharge) ની તારીખ તપાસો જેથી વધારાના દિવસનું ભાડું ન લાગે.',
        'તપાસો કે તમે અગાઉ જે એડવાન્સ પૈસા જમા કર્યા હતા તે કુલ બિલમાંથી બાદ કર્યા છે કે નહીં.',
        '"કન્ઝ્યુમેબલ્સ" (ગ્લોવ્ઝ, સિરીંજ, પાટા) માં વપરાયા વગરની વસ્તુઓ પાછી આપીને પૈસા કપાયા કે નહીં તે જુઓ.',
        'કોઈ ચાર્જ બે વાર લાગેલો દેખાય કે સમજાય નહીં, તો ચૂકવતાં પહેલાં સ્ટાફને સમજાવવા કહો.',
      ],
    },
    note: {
      en: 'Always keep printed receipts of every advance payment and the final discharge summary.',
      hi: 'हर जमा राशि की पक्की रसीद और छुट्टी का सारांश (Discharge Summary) संभालकर रखें।',
      gu: 'દરેક જમા રકમની પાકી રસીદ અને ડિસ્ચાર્જ સારાંશ (Discharge Summary) સાચવીને રાખો.',
    },
    followUps: [
      {
        id: 'fu-bill-terms',
        label: {
          en: 'Explain hospital bill words (ICU, OT, Consumables)',
          hi: 'बिल के शब्द (ICU, OT, Consumables) समझाएँ',
          gu: 'બિલના શબ્દો (ICU, OT, Consumables) સમજાવો',
        },
        query: {
          en: 'What do ICU, OT charges, and consumables mean on a bill?',
          hi: 'बिल में ICU, OT चार्ज और कंज्यूमेबल्स का क्या मतलब है?',
          gu: 'બિલમાં ICU, OT ચાર્જ અને કન્ઝ્યુમેબલ્સનો શું અર્થ થાય?',
        },
      },
      {
        id: 'fu-bill-rights',
        label: {
          en: 'What are my rights as a patient?',
          hi: 'मरीज़ के क्या अधिकार हैं?',
          gu: 'દર્દીના શું અધિકારો છે?',
        },
        query: {
          en: 'What are my rights as a patient?',
          hi: 'मरीज़ के रूप में मेरे क्या अधिकार हैं?',
          gu: 'દર્દી તરીકે મારા કયા અધિકારો છે?',
        },
      },
    ],
  },
  {
    id: 'bill-words-explained',
    category: 'bill',
    keywords: [
      'icu',
      'ot charges',
      'consumables',
      'nursing',
      'room rent',
      'consultation',
      'diagnostics',
      'lab',
      'meaning',
      'matlab',
      'arth',
      'आईसीयू',
      'ओटी',
      'कंज्यूमेबल्स',
      'આઈસીયુ',
      'ઓટી',
      'કન્ઝ્યુમેબલ્સ',
    ],
    title: {
      en: 'Common Words on a Hospital Bill',
      hi: 'अस्पताल बिल के आम शब्दों का सरल मतलब',
      gu: 'હોસ્પિટલ બિલના સામાન્ય શબ્દોનો સરળ અર્થ',
    },
    summary: {
      en: 'Hospital bills often use short English terms. Here is what the most common lines mean in simple words.',
      hi: 'अस्पताल के बिल में अक्सर अंग्रेज़ी के छोटे शब्द लिखे होते हैं। यहाँ उनका आसान मतलब दिया है:',
      gu: 'હોસ્પિટલ બિલમાં ઘણીવાર અંગ્રેજીના ટૂંકા શબ્દો લખેલા હોય છે. અહીં તેનો સરળ અર્થ આપેલો છે:',
    },
    points: {
      en: [
        'Consultation Fee: Money charged when a doctor visits or examines the patient.',
        'Room / Bed Rent: Daily charge for the bed (General Ward is lowest; Private Room is higher).',
        'OT (Operation Theatre) Charges: Charge for using the surgery room and machines.',
        'ICU Charges: Intensive Care Unit bed fee for close 24-hour monitoring.',
        'Consumables: Single-use items like syringes, gloves, cotton, IV tubes, and masks.',
      ],
      hi: [
        'Consultation Fee: डॉक्टर द्वारा मरीज़ को देखने या सलाह देने की फीस।',
        'Room / Bed Rent: कमरे या बेड का रोज़ाना किराया (जनरल वार्ड सबसे सस्ता होता है)।',
        'OT Charges: ऑपरेशन थिएटर और वहाँ की मशीनों के उपयोग का शुल्क।',
        'ICU Charges: गंभीर देखभाल वाले आईसीयू बेड और मशीनों का रोज़ाना शुल्क।',
        'Consumables: एक बार इस्तेमाल होने वाली चीज़ें जैसे सिरिंज, दस्ताने, रुई, ग्लूकोज़ नली और पट्टी।',
      ],
      gu: [
        'Consultation Fee: ડૉક્ટર દ્વારા દર્દીને તપાસવા કે સલાહ આપવાની ફી.',
        'Room / Bed Rent: રૂમ કે બેડનું રોજનું ભાડું (જનરલ વોર્ડ સૌથી ઓછું હોય છે).',
        'OT Charges: ઓપરેશન થિયેટર અને મશીનો વાપરવાનો ચાર્જ.',
        'ICU Charges: ૨૪ કલાક ખાસ દેખરેખ માટે આઈસીયુ બેડનો ચાર્જ.',
        'Consumables: એક વાર વપરાતી વસ્તુઓ જેવી કે સિરીંજ, ગ્લોવ્ઝ, રૂ, બાટલાની નળી અને પાટા.',
      ],
    },
    followUps: [
      {
        id: 'fu-bw-1',
        label: {
          en: 'How to check if the bill has mistakes?',
          hi: 'बिल में गलती कैसे पकड़ें?',
          gu: 'બિલમાં ભૂલ કેવી રીતે તપાસવી?',
        },
        query: {
          en: 'How can I understand my hospital bill?',
          hi: 'मैं अपने अस्पताल के बिल को कैसे समझूँ?',
          gu: 'હું મારા હોસ્પિટલના બિલને કેવી રીતે સમજું?',
        },
      },
    ],
  },
  {
    id: 'government-schemes',
    category: 'schemes',
    keywords: [
      'scheme',
      'schemes',
      'government',
      'ayushman',
      'pmjay',
      'pm-jay',
      'ma card',
      'amrutum',
      'free treatment',
      'jan aushadhi',
      'ration',
      'bpl',
      'yojana',
      'sarkari',
      'muft',
      'योजना',
      'आयुष्मान',
      'सरकारी',
      'मुफ्त',
      'યોજના',
      'આયુષ્માન',
      'સરકારી',
      'મફત',
      'મા કાર્ડ',
    ],
    title: {
      en: 'Government Healthcare Schemes That May Help',
      hi: 'मदद करने वाली प्रमुख सरकारी स्वास्थ्य योजनाएँ',
      gu: 'મદદરૂપ થઈ શકે તેવી મુખ્ય સરકારી આરોગ્ય યોજનાઓ',
    },
    summary: {
      en: 'India has central and state programs that help eligible families reduce hospital and medicine expenses. Official eligibility must always be checked at an official portal or hospital Aarogya Mitra desk.',
      hi: 'भारत में केंद्र और राज्य सरकार की कई योजनाएँ अस्पताल व दवाइयों का खर्च कम करने में मदद करती हैं। पात्रता की पक्की जांच हमेशा सरकारी पोर्टल या अस्पताल के आरोग्य मित्र डेस्क पर कराएँ।',
      gu: 'ભારતમાં કેન્દ્ર અને રાજ્ય સરકારની ઘણી યોજનાઓ હોસ્પિટલ અને દવાઓનો ખર્ચ ઘટાડવામાં મદદ કરે છે. પાત્રતાની પાકી તપાસ હંમેશા સરકારી પોર્ટલ કે હોસ્પિટલના આરોગ્ય મિત્ર ડેસ્ક પર કરાવો.',
    },
    points: {
      en: [
        'Ayushman Bharat (PM-JAY): Offers cashless hospitalization at empaneled hospitals for eligible families listed under official criteria.',
        'State Health Schemes (e.g., PM-JAY-MA / Mukhyamantri Amrutum in Gujarat, MJPJAY in Maharashtra): State cards may support families based on state income or ration card rules.',
        'Government Hospitals & PHCs: District hospitals, CHCs, and PHCs provide low-cost or free doctor visits and basic tests.',
        'Janani Shishu Suraksha Karyakram (JSSK): Supports free delivery care for pregnant women and sick newborns at public health facilities.',
        'Pradhan Mantri Jan Aushadhi Kendras: Government-supported stores selling quality generic medicines at lower prices.',
      ],
      hi: [
        'आयुष्मान भारत (PM-JAY): सरकारी नियमों के तहत पात्र परिवारों को जुड़े हुए अस्पतालों में कैशलेस भर्ती इलाज में मदद मिलती है।',
        'राज्य स्वास्थ्य योजनाएँ (जैसे गुजरात में PM-JAY-MA, महाराष्ट्र में MJPJAY): राज्य के राशन कार्ड या आय नियमों के अनुसार सहायता मिल सकती है।',
        'सरकारी अस्पताल और PHC: जिला अस्पताल व प्राथमिक स्वास्थ्य केंद्र में बहुत कम शुल्क या मुफ्त जांच व इलाज मिलता है।',
        'जननी शिशु सुरक्षा कार्यक्रम (JSSK): सरकारी अस्पतालों में गर्भवती महिलाओं के प्रसव और नवजात शिशु के इलाज में सहायता।',
        'जन औषधि केंद्र: सरकारी सहायता प्राप्त दुकानें जहाँ कम कीमत पर जेनेरिक दवाइयाँ मिलती हैं।',
      ],
      gu: [
        'આયુષ્માન ભારત (PM-JAY): સરકારી નિયમો મુજબ પાત્ર પરિવારોને જોડાયેલી હોસ્પિટલોમાં કેશલેસ સારવારમાં મદદ મળે છે.',
        'રાજ્ય આરોગ્ય યોજનાઓ (જેમ કે ગુજરાતમાં PM-JAY-MA / મા કાર્ડ): રાજ્યના રેશનકાર્ડ કે આવકના નિયમો મુજબ મદદ મળી શકે છે.',
        'સરકારી હોસ્પિટલ અને PHC: જિલ્લા હોસ્પિટલ અને પ્રાથમિક આરોગ્ય કેન્દ્રમાં મફત અથવા નજીવા દરે સારવાર અને રિપોર્ટ થાય છે.',
        'જનની શિશુ સુરક્ષા કાર્યક્રમ (JSSK): સરકારી હોસ્પિટલોમાં સગર્ભા બહેનોની પ્રસૂતિ અને નવજાત શિશુની સારવાર માટે મદદ.',
        'જન ઔષધિ કેન્દ્ર: સરકાર માન્ય દુકાનો જ્યાં ઓછા ભાવે જેનેરિક દવાઓ મળે છે.',
      ],
    },
    note: {
      en: 'Demo notice: Sahaay Voice does not verify or guarantee scheme eligibility. Carry Aadhaar and Ration Card to the hospital Aarogya Mitra help desk or CSC center to check.',
      hi: 'ध्यान दें: यह ऐप योजना की पात्रता की गारंटी नहीं देता। जांच के लिए आधार और राशन कार्ड लेकर अस्पताल के आरोग्य मित्र या जन सेवा केंद्र (CSC) जाएँ।',
      gu: 'નોંધ: આ એપ યોજનાની પાત્રતાની ખાતરી આપતું નથી. તપાસ માટે આધાર અને રેશનકાર્ડ લઈને હોસ્પિટલના આરોગ્ય મિત્ર કે CSC કેન્દ્ર પર જાઓ.',
    },
    followUps: [
      {
        id: 'fu-sch-docs',
        label: {
          en: 'What documents are needed for admission?',
          hi: 'भर्ती के लिए कौन-से कागज़ात चाहिए?',
          gu: 'દાખલ થવા કયા કાગળો જોઈએ?',
        },
        query: {
          en: 'What documents are needed for hospital admission?',
          hi: 'अस्पताल में भर्ती होने के लिए कौन-से कागज़ात चाहिए?',
          gu: 'હોસ્પિટલમાં દાખલ થવા માટે કયા કાગળોની જરૂર પડે છે?',
        },
      },
      {
        id: 'fu-sch-rights',
        label: {
          en: 'What are my rights as a patient?',
          hi: 'मरीज़ के अधिकार क्या हैं?',
          gu: 'દર્દીના અધિકારો શું છે?',
        },
        query: {
          en: 'What are my rights as a patient?',
          hi: 'मरीज़ के रूप में मेरे क्या अधिकार हैं?',
          gu: 'દર્દી તરીકે મારા કયા અધિકારો છે?',
        },
      },
    ],
  },
  {
    id: 'patient-rights',
    category: 'rights',
    keywords: [
      'right',
      'rights',
      'legal',
      'law',
      'consent',
      'complaint',
      'privacy',
      'records',
      'discharge',
      'adhikar',
      'hak',
      'kanoon',
      'अधिकार',
      'हक',
      'कानून',
      'शिकायत',
      'અધિકાર',
      'હક',
      'કાયદો',
      'ફરિયાદ',
    ],
    title: {
      en: 'Your Basic Rights as a Patient',
      hi: 'मरीज़ के रूप में आपके मुख्य अधिकार',
      gu: 'દર્દી તરીકે તમારા મૂળભૂત અધિકારો',
    },
    summary: {
      en: 'Every patient deserves safe, respectful care and honest information. Knowing these basic rights helps families speak up calmly.',
      hi: 'हर मरीज़ को सम्मानजनक देखभाल और सही जानकारी पाने का हक है। इन अधिकारों को जानने से परिवार शांत और आत्मविश्वास से बात रख सकता है।',
      gu: 'દરેક દર્દીને આદરપૂર્વકની સારવાર અને સાચી માહિતી મેળવવાનો હક છે. આ અધિકારો જાણવાથી પરિવાર શાંતિથી પોતાની વાત મૂકી શકે છે.',
    },
    points: {
      en: [
        'Right to Emergency Care: In life-threatening emergencies, hospitals are expected to stabilize the patient first.',
        'Right to Information & Consent: Doctors must explain the illness, procedure, risks, and cost before asking you to sign.',
        'Right to Records & Itemized Bills: You can ask for copies of test reports, discharge summary, and a detailed bill.',
        'Right to a Second Opinion: You are free to consult another qualified doctor before a major procedure.',
        'Right to Privacy & Respect: No discrimination based on income, caste, gender, or language.',
        'Where to Raise Concerns: Speak to the Hospital Grievance Officer, Medical Superintendent, or call 104 / National Consumer Helpline (1915).',
      ],
      hi: [
        'आपातकालीन देखभाल का अधिकार: जान को खतरा होने पर अस्पताल को पहले मरीज़ की स्थिति संभालनी चाहिए।',
        'जानकारी और सहमति का अधिकार: किसी भी साइन से पहले डॉक्टर को बीमारी, इलाज, जोखिम और खर्च समझाना चाहिए।',
        'रिपोर्ट और विस्तृत बिल का अधिकार: आपको अपनी जांच रिपोर्ट, डिस्चार्ज पेपर और पूरा बिल लेने का अधिकार है।',
        'दूसरी राय (Second Opinion) का अधिकार: बड़े ऑपरेशन से पहले आप किसी दूसरे डॉक्टर से भी सलाह ले सकते हैं।',
        'निजता और सम्मान का अधिकार: गरीबी, भाषा, जाति या लिंग के आधार पर कोई भेदभाव नहीं होना चाहिए।',
        'शिकायत कहाँ करें: अस्पताल के शिकायत अधिकारी, मेडिकल सुपरिंटेंडेंट से मिलें या 104 / राष्ट्रीय उपभोक्ता हेल्पलाइन (1915) पर बात करें।',
      ],
      gu: [
        'કટોકટીની સારવારનો અધિકાર: જીવનું જોખમ હોય તેવી સ્થિતિમાં હોસ્પિટલે પહેલા દર્દીની સ્થિતિ સ્થિર કરવી જોઈએ.',
        'માહિતી અને સંમતિનો અધિકાર: કોઈપણ સહી લેતા પહેલાં ડૉક્ટરે રોગ, સારવાર, જોખમ અને ખર્ચ સમજાવવો જોઈએ.',
        'રિપોર્ટ અને વિગતવાર બિલનો અધિકાર: તમને તમારા ટેસ્ટ રિપોર્ટ, ડિસ્ચાર્જ સારાંશ અને વિગતવાર બિલની નકલ લેવાનો હક છે.',
        'બીજા અભિપ્રાય (Second Opinion) નો અધિકાર: મોટા ઓપરેશન પહેલાં તમે બીજા ડૉક્ટરની સલાહ લઈ શકો છો.',
        'ગોપનીયતા અને સન્માનનો અધિકાર: આવક, ભાષા, જાતિ કે લિંગના આધારે કોઈ ભેદભાવ ન થવો જોઈએ.',
        'ફરિયાદ ક્યાં કરવી: હોસ્પિટલના ફરિયાદ અધિકારી, મેડિકલ સુપરિન્ટેન્ડેન્ટને મળો અથવા 104 / ગ્રાહક હેલ્પલાઇન (1915) પર કૉલ કરો.',
      ],
    },
    note: {
      en: 'This is general awareness information and not formal legal advice. For legal disputes, consult a qualified advocate or Legal Services Authority (NALSA 15100).',
      hi: 'यह केवल सामान्य जागरूकता जानकारी है, कानूनी सलाह नहीं। कानूनी मदद के लिए वकील या मुफ्त कानूनी सहायता (NALSA 15100) से संपर्क करें।',
      gu: 'આ ફક્ત સામાન્ય જાગૃતિ માટેની માહિતી છે, કાનૂની સલાહ નથી. કાનૂની મદદ માટે વકીલ અથવા મફત કાનૂની સેવા (NALSA 15100) નો સંપર્ક કરો.',
    },
    followUps: [
      {
        id: 'fu-rt-consent',
        label: {
          en: 'What to check before signing a consent form?',
          hi: 'सहमति फ़ॉर्म पर साइन से पहले क्या देखें?',
          gu: 'સંમતિ ફોર્મ પર સહી પહેલાં શું જોવું?',
        },
        query: {
          en: 'What should I check before signing a hospital consent form?',
          hi: 'सहमति फ़ॉर्म पर साइन करने से पहले क्या जांचें?',
          gu: 'સંમતિ ફોર્મ પર સહી કરતાં પહેલાં શું તપાસવું?',
        },
      },
      {
        id: 'fu-rt-bill',
        label: {
          en: 'How can I understand my hospital bill?',
          hi: 'अस्पताल का बिल कैसे समझें?',
          gu: 'હોસ્પિટલનું બિલ કેવી રીતે સમજવું?',
        },
        query: {
          en: 'How can I understand my hospital bill?',
          hi: 'मैं अपने अस्पताल के बिल को कैसे समझूँ?',
          gu: 'હું મારા હોસ્પિટલના બિલને કેવી રીતે સમજું?',
        },
      },
    ],
  },
  {
    id: 'consent-form',
    category: 'rights',
    keywords: [
      'consent',
      'sign',
      'signature',
      'form',
      'english form',
      'paper',
      'सहमत',
      'सहमति',
      'हस्ताक्षर',
      'साइन',
      'સંમતિ',
      'સહી',
      'ફોર્મ',
    ],
    title: {
      en: 'Before Signing Any Hospital Consent Form',
      hi: 'अस्पताल के सहमति फ़ॉर्म पर साइन करने से पहले क्या करें',
      gu: 'હોસ્પિટલના સંમતિ ફોર્મ પર સહી કરતાં પહેલાં શું કરવું',
    },
    summary: {
      en: 'Never feel rushed into signing an English form you cannot read. Ask a nurse, doctor, or family member to read and explain it in your own language.',
      hi: 'अगर फ़ॉर्म अंग्रेज़ी में है और आप पढ़ नहीं पा रहे हैं, तो जल्दी में साइन न करें। डॉक्टर, नर्स या परिजन से अपनी भाषा में पढ़कर समझाने को कहें।',
      gu: 'જો ફોર્મ અંગ્રેજીમાં હોય અને તમે વાંચી ન શકતા હો, તો ઉતાવળમાં સહી ન કરો. ડૉક્ટર, નર્સ કે પરિવારના સભ્યને તમારી ભાષામાં સમજાવવા કહો.',
    },
    points: {
      en: [
        'Ask: "Which exact procedure or test am I agreeing to?"',
        'Make sure the patient’s full name and age are written correctly on the form.',
        'Do not sign completely blank sheets.',
        'Ask if the form also mentions estimated costs or room category.',
      ],
      hi: [
        'पूछें: "मैं किस जांच या ऑपरेशन के लिए सहमति दे रहा हूँ?"',
        'जांच लें कि फ़ॉर्म पर मरीज़ का पूरा नाम और उम्र सही लिखी है।',
        'खाली या अधूरे कागज़ पर साइन न करें।',
        'पूछें कि क्या इस फ़ॉर्म में कमरे की श्रेणी या खर्च की बात भी लिखी है।',
      ],
      gu: [
        'પૂછો: "હું કઈ સારવાર કે ઓપરેશન માટે સંમતિ આપી રહ્યો છું?"',
        'તપાસો કે ફોર્મ પર દર્દીનું પૂરું નામ અને ઉંમર સાચા લખ્યા છે.',
        'કોરા કે અધૂરા કાગળ પર સહી ન કરો.',
        'પૂછો કે શું આ ફોર્મમાં રૂમના પ્રકાર કે ખર્ચની વિગત પણ લખેલી છે.',
      ],
    },
    followUps: [
      {
        id: 'fu-cf-1',
        label: {
          en: 'What are my rights as a patient?',
          hi: 'मरीज़ के अधिकार क्या हैं?',
          gu: 'દર્દીના અધિકારો શું છે?',
        },
        query: {
          en: 'What are my rights as a patient?',
          hi: 'मरीज़ के रूप में मेरे क्या अधिकार हैं?',
          gu: 'દર્દી તરીકે મારા કયા અધિકારો છે?',
        },
      },
    ],
  },
  {
    id: 'admission-documents',
    category: 'admission',
    keywords: [
      'document',
      'documents',
      'admission',
      'admit',
      'kagaz',
      'paper',
      'id',
      'aadhaar',
      'aadhar',
      'ration',
      'checklist',
      'bharti',
      'कागज़',
      'कागजात',
      'दस्तावेज़',
      'भर्ती',
      'आधार',
      'દસ્તાવેજ',
      'કાગળો',
      'દાખલ',
      'આધાર',
    ],
    title: {
      en: 'Documents Needed for Hospital Admission',
      hi: 'अस्पताल में भर्ती होने के लिए ज़रूरी कागज़ात',
      gu: 'હોસ્પિટલમાં દાખલ થવા માટે જરૂરી કાગળો',
    },
    summary: {
      en: 'Keeping these papers together in one plastic folder saves time and prevents stress at the admission counter.',
      hi: 'इन सभी कागज़ात को एक फाइल या प्लास्टिक फ़ोल्डर में साथ रखने से भर्ती के समय परेशानी नहीं होती।',
      gu: 'આ બધા કાગળોને એક ફાઇલ કે ફોલ્ડરમાં સાથે રાખવાથી દાખલ થતી વખતે દોડધામ થતી નથી.',
    },
    points: {
      en: [
        'Government Photo ID: Aadhaar Card, Voter ID, or Driving Licence of the patient and attendant.',
        'Health Scheme / Insurance Card: Ayushman Bharat (PM-JAY), State Card (like MA Card), ESIC, or private policy copy.',
        'Ration Card or Income Certificate: Helpful if applying for government scheme or charitable ward concessions.',
        'Doctor’s Admission Note & Past Reports: Old prescriptions, blood tests, X-ray/scan reports, and current medicine list.',
        'Emergency Contact Numbers & Small Cash/UPI: Write two family phone numbers clearly on paper.',
      ],
      hi: [
        'सरकारी पहचान पत्र: मरीज़ और साथ रहने वाले परिजन का आधार कार्ड, वोटर आईडी या ड्राइविंग लाइसेंस।',
        'स्वास्थ्य कार्ड / बीमा: आयुष्मान भारत (PM-JAY), राज्य कार्ड, ESIC या निजी बीमा कार्ड।',
        'राशन कार्ड या आय प्रमाण पत्र: सरकारी योजना या ट्रस्ट अस्पताल में छूट के लिए उपयोगी।',
        'डॉक्टर की भर्ती पर्ची और पुरानी रिपोर्ट: पुराने पर्चे, खून की जांच, एक्स-रे/स्कैन और अभी चल रही दवाइयों की सूची।',
        'परिवार के दो फोन नंबर और ज़रूरी खर्च के लिए नकद/UPI।',
      ],
      gu: [
        'સરકારી ઓળખપત્ર: દર્દી અને સાથે રહેનાર સભ્યનું આધાર કાર્ડ, ચૂંટણી કાર્ડ અથવા ડ્રાઇવિંગ લાઇસન્સ.',
        'આરોગ્ય કાર્ડ / વીમો: આયુષ્માન ભારત (PM-JAY), મા કાર્ડ, ESIC અથવા ખાનગી વીમા કાર્ડ.',
        'રેશનકાર્ડ અથવા આવકનો દાખલો: સરકારી યોજના કે ટ્રસ્ટની હોસ્પિટલમાં રાહત માટે ઉપયોગી.',
        'ડૉક્ટરની દાખલ ચિઠ્ઠી અને જૂના રિપોર્ટ: જૂના પ્રિસ્ક્રિપ્શન, લોહીના રિપોર્ટ, એક્સ-રે અને હાલની દવાઓની યાદી.',
        'પરિવારના બે ફોન નંબર લખેલી ચિઠ્ઠી અને જરૂરી ખર્ચ માટે રોકડ/UPI.',
      ],
    },
    note: {
      en: 'You can use the "Documents" tab in this app to tick off each paper as you pack it.',
      hi: 'आप इस ऐप के "कागज़ात" टैब में जाकर हर तैयार कागज़ पर सही का निशान लगा सकते हैं।',
      gu: 'તમે આ એપના "કાગળો" વિભાગમાં જઈને દરેક તૈયાર કાગળ પર નિશાન લગાવી શકો છો.',
    },
    followUps: [
      {
        id: 'fu-doc-1',
        label: {
          en: 'Which government schemes may help me?',
          hi: 'कौन-सी सरकारी योजनाएँ मदद कर सकती हैं?',
          gu: 'કઈ સરકારી યોજનાઓ મદદ કરી શકે?',
        },
        query: {
          en: 'Which government healthcare schemes may help me?',
          hi: 'कौन-सी सरकारी स्वास्थ्य योजनाएँ मेरी मदद कर सकती हैं?',
          gu: 'કઈ સરકારી આરોગ્ય યોજનાઓ મને મદદ કરી શકે છે?',
        },
      },
      {
        id: 'fu-doc-2',
        label: {
          en: 'What should I ask before an operation?',
          hi: 'ऑपरेशन से पहले क्या पूछें?',
          gu: 'ઓપરેશન પહેલાં શું પૂછવું?',
        },
        query: {
          en: 'What should I ask before an operation?',
          hi: 'ऑपरेशन से पहले डॉक्टर से क्या पूछना चाहिए?',
          gu: 'ઓપરેશન પહેલાં ડૉક્ટરને શું પૂછવું જોઈએ?',
        },
      },
    ],
  },
];

export const FALLBACK_INTENT: KnowledgeIntent = {
  id: 'fallback-general',
  category: 'general',
  keywords: [],
  title: {
    en: 'Here Is How Sahaay Voice Can Help',
    hi: 'सहाय वॉइस आपकी इस तरह मदद कर सकता है',
    gu: 'સહાય વૉઇસ તમને આ રીતે મદદ કરી શકે છે',
  },
  summary: {
    en: 'I did not catch that exact topic in this demo guide. I cannot diagnose health problems or suggest medicines, but I can clearly explain these hospital topics:',
    hi: 'इस डेमो गाइड में आपका यह सवाल ठीक से नहीं मिला। मैं बीमारी की जांच या दवा नहीं बता सकता, लेकिन इन विषयों में आपकी मदद कर सकता हूँ:',
    gu: 'આ ડેમો માર્ગદર્શિકામાં તમારો આ પ્રશ્ન બરાબર મળ્યો નહીં. હું રોગનું નિદાન કે દવા સૂચવી શકતો નથી, પરંતુ આ વિષયોમાં મદદ કરી શકું છું:',
  },
  points: {
    en: [
      'Questions to ask before an operation and how to ask for a cost estimate.',
      'How to read and verify a hospital bill.',
      'Government healthcare schemes (like PM-JAY / state schemes) and where to check eligibility.',
      'Basic patient rights, consent forms, and hospital admission documents.',
    ],
    hi: [
      'ऑपरेशन से पहले डॉक्टर से पूछने वाले सवाल और खर्च का अनुमान।',
      'अस्पताल का बिल पढ़ने और जांचने का तरीका।',
      'सरकारी स्वास्थ्य योजनाएँ (जैसे आयुष्मान भारत) और पात्रता जांचने की जगह।',
      'मरीज़ के अधिकार, सहमति फ़ॉर्म और भर्ती के कागज़ात की सूची।',
    ],
    gu: [
      'ઓપરેશન પહેલાં ડૉક્ટરને પૂછવાના પ્રશ્નો અને ખર્ચનો અંદાજ.',
      'હોસ્પિટલનું બિલ વાંચવાની અને તપાસવાની રીત.',
      'સરકારી આરોગ્ય યોજનાઓ (જેમ કે આયુષ્માન ભારત) અને પાત્રતા તપાસવાની રીત.',
      'દર્દીના અધિકારો, સંમતિ ફોર્મ અને દાખલ થવાના કાગળોની યાદી.',
    ],
  },
  followUps: [
    {
      id: 'fu-fb-1',
      label: {
        en: 'What should I ask before an operation?',
        hi: 'ऑपरेशन से पहले क्या पूछें?',
        gu: 'ઓપરેશન પહેલાં શું પૂછવું?',
      },
      query: {
        en: 'What should I ask before an operation?',
        hi: 'ऑपरेशन से पहले डॉक्टर से क्या पूछना चाहिए?',
        gu: 'ઓપરેશન પહેલાં ડૉક્ટરને શું પૂછવું જોઈએ?',
      },
    },
    {
      id: 'fu-fb-2',
      label: {
        en: 'How can I understand my hospital bill?',
        hi: 'अस्पताल का बिल कैसे समझें?',
        gu: 'હોસ્પિટલનું બિલ કેવી રીતે સમજવું?',
      },
      query: {
        en: 'How can I understand my hospital bill?',
        hi: 'मैं अपने अस्पताल के बिल को कैसे समझूँ?',
        gu: 'હું મારા હોસ્પિટલના બિલને કેવી રીતે સમજું?',
      },
    },
    {
      id: 'fu-fb-3',
      label: {
        en: 'What documents are needed for admission?',
        hi: 'भर्ती के कागज़ात की सूची',
        gu: 'દાખલ થવાના કાગળોની યાદી',
      },
      query: {
        en: 'What documents are needed for hospital admission?',
        hi: 'अस्पताल में भर्ती होने के लिए कौन-से कागज़ात चाहिए?',
        gu: 'હોસ્પિટલમાં દાખલ થવા માટે કયા કાગળોની જરૂર પડે છે?',
      },
    },
  ],
};

export const TOPIC_GUIDES: TopicGuide[] = [
  {
    id: 'operation',
    title: {
      en: 'Operation & Cost Information',
      hi: 'ऑपरेशन और खर्च की जानकारी',
      gu: 'ઓપરેશન અને ખર્ચની માહિતી',
    },
    subtitle: {
      en: 'Questions to ask before surgery and how to understand written estimates',
      hi: 'सर्जरी से पहले पूछने वाले सवाल और लिखित खर्च अनुमान समझना',
      gu: 'સર્જરી પહેલાં પૂછવાના પ્રશ્નો અને લેખિત ખર્ચ અંદાજ સમજવો',
    },
    intro: {
      en: 'Before any operation, take time to ask clear questions. Good hospitals welcome questions from families.',
      hi: 'किसी भी ऑपरेशन से पहले शांत मन से सभी ज़रूरी सवाल पूछें। अच्छा अस्पताल हमेशा परिवार को पूरी बात समझाता है।',
      gu: 'કોઈપણ ઓપરેશન પહેલાં શાંતિથી બધા જરૂરી પ્રશ્નો પૂછો. સારી હોસ્પિટલ હંમેશા પરિવારને પૂરી વાત સમજાવે છે.',
    },
    sections: [
      {
        heading: {
          en: '1. Questions for the Surgeon',
          hi: '1. सर्जन (डॉक्टर) से पूछने वाले सवाल',
          gu: '1. સર્જન (ડૉક્ટર) ને પૂછવાના પ્રશ્નો',
        },
        bullets: {
          en: [
            'Why is this operation needed right now, and are there non-surgical choices?',
            'What type of anesthesia will be used, and what are the main risks?',
            'How many days will the patient stay in the hospital and need rest at home?',
          ],
          hi: [
            'यह ऑपरेशन अभी क्यों ज़रूरी है, और क्या बिना ऑपरेशन के कोई रास्ता है?',
            'किस तरह की बेहोशी दी जाएगी और इसमें क्या मुख्य जोखिम हो सकते हैं?',
            'अस्पताल में कितने दिन रहना होगा और घर पर कितने दिन आराम चाहिए?',
          ],
          gu: [
            'આ ઓપરેશન અત્યારે કેમ જરૂરી છે, અને શું ઓપરેશન વગર બીજો ઉપાય છે?',
            'કયા પ્રકારનું બેભાન (એનેસ્થેસિયા) અપાશે અને મુખ્ય જોખમ શું હોઈ શકે?',
            'હોસ્પિટલમાં કેટલા દિવસ રહેવું પડશે અને ઘરે કેટલા દિવસ આરામ જોઈશે?',
          ],
        },
      },
      {
        heading: {
          en: '2. Understanding Operation Costs',
          hi: '2. ऑपरेशन के खर्च को समझना',
          gu: '2. ઓપરેશનના ખર્ચને સમજવો',
        },
        bullets: {
          en: [
            'Ask the billing desk for a written estimate before admission.',
            'Check whether the price is a single package or itemized.',
            'Confirm if implants, ICU stay, blood tests, and follow-up visits are extra.',
            'Ask about General Ward rates vs Semi-Private room rates to match your budget.',
          ],
          hi: [
            'भर्ती से पहले बिलिंग डेस्क से खर्च का लिखित अनुमान (Estimate) लें।',
            'पता करें कि खर्च एक पैकेज में है या हर चीज़ का बिल अलग बनेगा।',
            'पूछें कि इम्प्लांट, आईसीयू, खून की जांच और बाद की विज़िट अलग से लगेंगे या नहीं।',
            'अपने बजट के अनुसार जनरल वार्ड और प्राइवेट कमरे के किराये का अंतर पूछें।',
          ],
          gu: [
            'દાખલ થતાં પહેલાં બિલિંગ ડેસ્ક પાસેથી ખર્ચનો લેખિત અંદાજ (Estimate) લો.',
            'જાણો કે ખર્ચ એક પૅકેજમાં છે કે દરેક વસ્તુનો અલગ ચાર્જ લાગશે.',
            'પૂછો કે ઇમ્પ્લાન્ટ, આઈસીયુ, રિપોર્ટ અને પછીની મુલાકાતનો ચાર્જ અલગ છે કે નહીં.',
            'તમારા બજેટ મુજબ જનરલ વોર્ડ અને પ્રાઇવેટ રૂમના ભાડાનો તફાવત પૂછો.',
          ],
        },
      },
    ],
    sampleQuestion: {
      en: 'What should I ask before an operation?',
      hi: 'ऑपरेशन से पहले डॉक्टर से क्या पूछना चाहिए?',
      gu: 'ઓપરેશન પહેલાં ડૉક્ટરને શું પૂછવું જોઈએ?',
    },
  },
  {
    id: 'bill',
    title: {
      en: 'Hospital Bill Explanations',
      hi: 'अस्पताल के बिल की समझ',
      gu: 'હોસ્પિટલ બિલની સમજૂતી',
    },
    subtitle: {
      en: 'How to read itemized bills, check deposits, and spot common errors',
      hi: 'विस्तृत बिल पढ़ना, जमा राशि जांचना और बिल के शब्दों का मतलब',
      gu: 'વિગતવાર બિલ વાંચવું, જમા રકમ તપાસવી અને બિલના શબ્દોનો અર્થ',
    },
    intro: {
      en: 'You always have the right to ask for a clear line-by-line bill and take time to check it with a family member.',
      hi: 'आपको हमेशा पूरा विस्तृत बिल मांगने और किसी परिजन के साथ बैठकर उसे जांचने का अधिकार है।',
      gu: 'તમને હંમેશા વિગતવાર બિલ માંગવાનો અને પરિવારના સભ્ય સાથે બેસીને તેને તપાસવાનો પૂરો અધિકાર છે.',
    },
    sections: [
      {
        heading: {
          en: 'Steps Before Paying the Final Bill',
          hi: 'अंतिम बिल भरने से पहले करने वाले 4 काम',
          gu: 'અંતિમ બિલ ચૂકવતાં પહેલાં કરવાના 4 કામ',
        },
        bullets: {
          en: [
            'Request the full itemized bill — not just a single summary slip.',
            'Count the exact number of bed/room days from admission to discharge.',
            'Verify all advance deposit receipts are deducted.',
            'Ask for the printed Discharge Summary and all original test reports.',
          ],
          hi: [
            'सिर्फ कुल रकम की पर्ची नहीं, बल्कि पूरा विस्तृत बिल (Itemized Bill) मांगें।',
            'भर्ती से छुट्टी तक के कमरे/बेड के दिनों की गिनती मिलाएँ।',
            'जांचें कि पहले जमा की गई सभी रसीदें बिल में से घटाई गई हैं।',
            'छुट्टी का सारांश (Discharge Summary) और सभी जांच रिपोर्ट साथ लें।',
          ],
          gu: [
            'માત્ર કુલ રકમની ચિઠ્ઠી નહીં, પરંતુ પૂરું વિગતવાર બિલ (Itemized Bill) માંગો.',
            'દાખલ થયાથી રજા સુધીના રૂમ/બેડના દિવસોની ગણતરી તપાસો.',
            'અગાઉ જમા કરેલી બધી રસીદો બિલમાંથી બાદ થઈ છે કે નહીં તે જુઓ.',
            'ડિસ્ચાર્જ સારાંશ (Discharge Summary) અને બધા જૂના-નવા રિપોર્ટ સાથે લો.',
          ],
        },
      },
    ],
    sampleQuestion: {
      en: 'How can I understand my hospital bill?',
      hi: 'मैं अपने अस्पताल के बिल को कैसे समझूँ?',
      gu: 'હું મારા હોસ્પિટલના બિલને કેવી રીતે સમજું?',
    },
  },
  {
    id: 'schemes',
    title: {
      en: 'Government Healthcare Schemes',
      hi: 'सरकारी स्वास्थ्य योजनाएँ',
      gu: 'સરકારી આરોગ્ય યોજનાઓ',
    },
    subtitle: {
      en: 'Overview of major public support programs and where to verify eligibility',
      hi: 'प्रमुख सरकारी स्वास्थ्य योजनाओं की जानकारी और जांच करने का तरीका',
      gu: 'મુખ્ય સરકારી આરોગ્ય યોજનાઓની માહિતી અને પાત્રતા તપાસવાની રીત',
    },
    intro: {
      en: 'Many families miss out on free or subsidized care simply because they do not know about the Aarogya Mitra desk at hospitals.',
      hi: 'कई परिवार केवल जानकारी न होने की वजह से मुफ्त या कम खर्च वाले सरकारी इलाज का लाभ नहीं ले पाते।',
      gu: 'ઘણા પરિવારો માત્ર માહિતીના અભાવે મફત અથવા ઓછા ખર્ચવાળી સરકારી સારવારનો લાભ લઈ શકતા નથી.',
    },
    sections: [
      {
        heading: {
          en: 'Common Public Health Support Programs',
          hi: 'प्रमुख सरकारी स्वास्थ्य सहायता कार्यक्रम',
          gu: 'મુખ્ય સરકારી આરોગ્ય સહાય કાર્યક્રમો',
        },
        bullets: {
          en: [
            'Ayushman Bharat (PM-JAY): Cashless inpatient care at empaneled hospitals for eligible families.',
            'State Health Cards (e.g., PM-JAY-MA in Gujarat, MJPJAY in Maharashtra): State-level support based on state rules.',
            'Public Hospitals (PHC, CHC, District Hospital): Free or very low-cost doctor visits and essential care.',
            'Janani Shishu Suraksha Karyakram (JSSK): Free maternity delivery and newborn care in public hospitals.',
            'Jan Aushadhi Kendra: Quality generic medicines at affordable prices.',
          ],
          hi: [
            'आयुष्मान भारत (PM-JAY): पात्र परिवारों को जुड़े अस्पतालों में कैशलेस भर्ती इलाज में सहायता।',
            'राज्य योजनाएँ (जैसे गुजरात में PM-JAY-MA, महाराष्ट्र में MJPJAY): राज्य सरकार के नियमों के अनुसार सहायता।',
            'सरकारी अस्पताल (PHC, CHC, जिला अस्पताल): मुफ्त या बहुत कम शुल्क में डॉक्टर परामर्श और इलाज।',
            'जननी शिशु सुरक्षा कार्यक्रम (JSSK): सरकारी अस्पतालों में प्रसव और नवजात शिशु की मुफ्त देखभाल।',
            'जन औषधि केंद्र: सस्ती दरों पर अच्छी गुणवत्ता की जेनेरिक दवाइयाँ।',
          ],
          gu: [
            'આયુષ્માન ભારત (PM-JAY): પાત્ર પરિવારોને જોડાયેલી હોસ્પિટલોમાં કેશલેસ દાખલ સારવારમાં સહાય.',
            'રાજ્ય યોજનાઓ (જેમ કે ગુજરાતમાં PM-JAY-MA / મા કાર્ડ): રાજ્ય સરકારના નિયમો મુજબ સહાય.',
            'સરકારી હોસ્પિટલ (PHC, CHC, જિલ્લા હોસ્પિટલ): મફત કે નજીવા દરે ડૉક્ટર તપાસ અને સારવાર.',
            'જનની શિશુ સુરક્ષા કાર્યક્રમ (JSSK): સરકારી હોસ્પિટલોમાં પ્રસૂતિ અને નવજાત શિશુની મફત સંભાળ.',
            'જન ઔષધિ કેન્દ્ર: સસ્તા દરે ગુણવત્તાયુક્ત જેનેરિક દવાઓ.',
          ],
        },
      },
      {
        heading: {
          en: 'How to Check Official Eligibility',
          hi: 'अपनी पात्रता की पक्की जांच कहाँ करें',
          gu: 'તમારી પાત્રતાની પાકી તપાસ ક્યાં કરવી',
        },
        bullets: {
          en: [
            'Visit the "Aarogya Mitra" counter inside any empaneled hospital with your Aadhaar & Ration Card.',
            'Visit a nearby Common Service Centre (CSC) / e-Gram center.',
            'Check official government websites like beneficiary.nha.gov.in or call 14555.',
          ],
          hi: [
            'आधार और राशन कार्ड लेकर अस्पताल के "आरोग्य मित्र" काउंटर पर जाएँ।',
            'नजदीकी जन सेवा केंद्र (CSC) पर जाकर अपना नाम जांचवाएँ।',
            'आधिकारिक वेबसाइट beneficiary.nha.gov.in देखें या 14555 पर जानकारी लें।',
          ],
          gu: [
            'આધાર અને રેશનકાર્ડ લઈને હોસ્પિટલના "આરોગ્ય મિત્ર" કાઉન્ટર પર જાઓ.',
            'નજીકના CSC કે ગ્રામ પંચાયત VCE કેન્દ્ર પર જઈને નામ તપাসાવો.',
            'સરકારી વેબસાઇટ beneficiary.nha.gov.in જુઓ અથવા 14555 પર માહિતી મેળવો.',
          ],
        },
      },
    ],
    sampleQuestion: {
      en: 'Which government healthcare schemes may help me?',
      hi: 'कौन-सी सरकारी स्वास्थ्य योजनाएँ मेरी मदद कर सकती हैं?',
      gu: 'કઈ સરકારી આરોગ્ય યોજનાઓ મને મદદ કરી શકે છે?',
    },
  },
  {
    id: 'rights',
    title: {
      en: 'Patient Rights & Basic Legal Info',
      hi: 'मरीज़ के अधिकार और बुनियादी कानूनी जानकारी',
      gu: 'દર્દીના અધિકારો અને મૂળભૂત કાનૂની માહિતી',
    },
    subtitle: {
      en: 'Dignity, informed consent, access to records, and complaint helplines',
      hi: 'सम्मान, सहमति, मेडिकल रिकॉर्ड पाने का हक और मदद हेल्पलाइन',
      gu: 'સન્માન, સંમતિ, મેડિકલ રેકોર્ડ મેળવવાનો હક અને મદદ હેલ્પલાઇન',
    },
    intro: {
      en: 'Understanding patient rights helps families stay informed and treated with dignity. This is general information, not legal representation.',
      hi: 'मरीज़ के अधिकार जानने से परिवार को सम्मानजनक और पारदर्शी इलाज मिलने में मदद मिलती है। यह सामान्य जानकारी है, कानूनी सलाह नहीं।',
      gu: 'દર્દીના અધિકારો જાણવાથી પરિવારને સન્માનપૂર્વક અને પારદર્શક સારવાર મળવામાં મદદ થાય છે. આ સામાન્ય માહિતી છે, કાનૂની સલાહ નથી.',
    },
    sections: [
      {
        heading: {
          en: 'Core Patient Rights',
          hi: 'मरीज़ के मुख्य अधिकार',
          gu: 'દર્દીના મુખ્ય અધિકારો',
        },
        bullets: {
          en: [
            'Emergency stabilization care regardless of ability to pay immediately.',
            'Clear explanation in your language before signing any consent form.',
            'Receiving copies of medical records, prescriptions, and itemized bills.',
            'Seeking a second medical opinion without fear or pressure.',
            'Privacy during examination and respectful care without discrimination.',
          ],
          hi: [
            'आपात स्थिति में तुरंत प्राथमिक जीवन-रक्षक देखभाल पाना।',
            'किसी भी सहमति फ़ॉर्म पर साइन करने से पहले अपनी भाषा में पूरी बात समझना।',
            'मेडिकल रिपोर्ट, डिस्चार्ज पेपर और विस्तृत बिल की कॉपी प्राप्त करना।',
            'बिना किसी दबाव के दूसरे डॉक्टर की राय (Second Opinion) लेने की आज़ादी।',
            'जांच के समय निजता और बिना किसी भेदभाव के सम्मानजनक व्यवहार।',
          ],
          gu: [
            'કટોકટીની સ્થિતિમાં તાત્કાલિક પ્રાથમિક જીવનરક્ષક સંભાળ મેળવવી.',
            'કોઈપણ સંમતિ ફોર્મ પર સહી કરતાં પહેલાં તમારી ભાષામાં પૂરી વાત સમજવી.',
            'મેડિકલ રિપોર્ટ, ડિસ્ચાર્જ પેપર અને વિગતવાર બિલની નકલ મેળવવી.',
            'કોઈપણ દબાણ વગર બીજા ડૉક્ટરનો અભિપ્રાય (Second Opinion) લેવાની સ્વતંત્રતા.',
            'તપાસ દરમિયાન ગોપનીયતા અને કોઈપણ ભેદભાવ વગર આદરપૂર્વકની વર્તણૂક.',
          ],
        },
      },
      {
        heading: {
          en: 'Useful Public Helplines (India)',
          hi: 'उपयोगी सरकारी हेल्पलाइन नंबर (भारत)',
          gu: 'ઉપયોગી સરકારી હેલ્પલાઇન નંબર (ભારત)',
        },
        bullets: {
          en: [
            '108 — Medical Ambulance Emergency',
            '104 — State Health Advisory & Grievance Helpline (in participating states)',
            '14555 — Ayushman Bharat (PM-JAY) Information Helpline',
            '1915 — National Consumer Helpline',
            '15100 — NALSA Free Legal Aid Helpline',
          ],
          hi: [
            '108 — आपातकालीन एम्बुलेंस सेवा',
            '104 — राज्य स्वास्थ्य सलाह और शिकायत हेल्पलाइन (लागू राज्यों में)',
            '14555 — आयुष्मान भारत (PM-JAY) जानकारी हेल्पलाइन',
            '1915 — राष्ट्रीय उपभोक्ता हेल्पलाइन',
            '15100 — NALSA मुफ्त कानूनी सहायता हेल्पलाइन',
          ],
          gu: [
            '108 — કટોકટી એમ્બ્યુલન્સ સેવા',
            '104 — રાજ્ય આરોગ્ય સલાહ અને ફરિયાદ હેલ્પલાઇન',
            '14555 — આયુષ્માન ભારત (PM-JAY) માહિતી હેલ્પલાઇન',
            '1915 — રાષ્ટ્રીય ગ્રાહક હેલ્પલાઇન',
            '15100 — NALSA મફત કાનૂની સહાય હેલ્પલાઇન',
          ],
        },
      },
    ],
    sampleQuestion: {
      en: 'What are my rights as a patient?',
      hi: 'मरीज़ के रूप में मेरे क्या अधिकार हैं?',
      gu: 'દર્દી તરીકે મારા કયા અધિકારો છે?',
    },
  },
];

export const BILL_TERMS: BillTerm[] = [
  {
    id: 'term-consultation',
    term: {
      en: 'Consultation / Doctor Visit Fee',
      hi: 'Consultation Fee (डॉक्टर विज़िट शुल्क)',
      gu: 'Consultation Fee (ડૉક્ટર તપાસ ફી)',
    },
    simpleMeaning: {
      en: 'Fee charged each time a doctor or specialist examines the admitted patient.',
      hi: 'भर्ती मरीज़ को देखने और सलाह देने के लिए डॉक्टर का शुल्क।',
      gu: 'દાખલ દર્દીને તપાસવા અને સલાહ આપવા માટે ડૉક્ટરની ફી.',
    },
    whatToCheck: {
      en: 'Check that the number of billed visits matches the days the doctor actually visited.',
      hi: 'जांचें कि बिल में उतनी ही विज़िट लिखी हों जितने दिन डॉक्टर देखने आए थे।',
      gu: 'તપાસો કે બિલમાં લખેલી મુલાકાતો ડૉક્ટર ખરેખર આવ્યા તે દિવસો મુજબ જ છે.',
    },
  },
  {
    id: 'term-room',
    term: {
      en: 'Room / Bed / Ward Rent',
      hi: 'Room / Bed Rent (कमरे या बेड का किराया)',
      gu: 'Room / Bed Rent (રૂમ અથવા બેડનું ભાડું)',
    },
    simpleMeaning: {
      en: 'Daily charge for staying in General Ward, Semi-Private, or Private room.',
      hi: 'जनरल वार्ड, सेमी-प्राइवेट या प्राइवेट कमरे में रहने का रोज़ाना किराया।',
      gu: 'જનરલ વોર્ડ, સેમી-પ્રાઇવેટ કે પ્રાઇવેટ રૂમમાં રહેવાનું રોજનું ભાડું.',
    },
    whatToCheck: {
      en: 'Confirm check-in/check-out time rules so half-day stays are not charged twice.',
      hi: 'भर्ती और छुट्टी के समय के नियम पूछें ताकि आधे दिन का पूरा दो दिन का किराया न लगे।',
      gu: 'દાખલ અને રજાના સમયના નિયમો પૂછો જેથી વધારાના દિવસનું ભાડું ન લાગે.',
    },
  },
  {
    id: 'term-ot',
    term: {
      en: 'OT (Operation Theatre) & Anesthesia',
      hi: 'OT और Anesthesia शुल्क',
      gu: 'OT અને Anesthesia ચાર્જ',
    },
    simpleMeaning: {
      en: 'Charge for using the surgery room, equipment, and the doctor who numbs pain during surgery.',
      hi: 'ऑपरेशन कमरे, मशीनों और ऑपरेशन के समय बेहोशी देने वाले डॉक्टर का शुल्क।',
      gu: 'ઓપરેશન રૂમ, મશીનો અને ઓપરેશન વખતે બેભાન કરનાર ડૉક્ટરનો ચાર્જ.',
    },
    whatToCheck: {
      en: 'Ask if these are already inside your surgery package or billed separately.',
      hi: 'पूछें कि क्या यह खर्च आपके सर्जरी पैकेज में शामिल था या अलग से जोड़ा गया है।',
      gu: 'પૂછો કે આ ચાર્જ તમારા સર્જરી પૅકેજમાં સામેલ હતો કે અલગથી ઉમેર્યો છે.',
    },
  },
  {
    id: 'term-consumables',
    term: {
      en: 'Consumables & Pharmacy',
      hi: 'Consumables और Pharmacy (दवाइयाँ)',
      gu: 'Consumables અને Pharmacy (દવાઓ)',
    },
    simpleMeaning: {
      en: 'Syringes, gloves, IV drips, bandages, and medicines used during care.',
      hi: 'इलाज में इस्तेमाल होने वाली सिरिंज, दस्ताने, ग्लूकोज़ की बोतल, पट्टी और दवाइयाँ।',
      gu: 'સારવારમાં વપરાતી સિરીંજ, ગ્લોવ્ઝ, બાટલા, પાટા અને દવાઓ.',
    },
    whatToCheck: {
      en: 'Ask for the pharmacy item list and check if unused sealed items can be returned.',
      hi: 'दवाइयों की पूरी सूची मांगें और पूछें कि बिना खुली बची हुई दवाइयाँ वापस होंगी या नहीं।',
      gu: 'દવાઓની પૂરી યાદી માંગો અને વપરાયા વગરની બંધ દવાઓ પાછી લેવાય છે કે નહીં તે પૂછો.',
    },
  },
  {
    id: 'term-diagnostics',
    term: {
      en: 'Diagnostics / Lab & Imaging',
      hi: 'Diagnostics / Lab (खून जांच, एक्स-रे)',
      gu: 'Diagnostics / Lab (લોહી તપાસ, એક્સ-રે)',
    },
    simpleMeaning: {
      en: 'Charges for blood tests, urine tests, X-ray, ultrasound, CT, or MRI scans.',
      hi: 'खून, पेशाब की जांच, एक्स-रे, सोनोग्राफी, सीटी या एमआरआई स्कैन का शुल्क।',
      gu: 'લોહી, પેશાબના રિપોર્ટ, એક્સ-રે, સોનોગ્રાફી, સીટી કે એમઆરઆઈ સ્કેનનો ચાર્જ.',
    },
    whatToCheck: {
      en: 'Collect printed copies of every test report you paid for.',
      hi: 'जिन भी जांचों का पैसा लगा है, उन सभी की प्रिंट की हुई रिपोर्ट ज़रूर लें।',
      gu: 'જે પણ રિપોર્ટના પૈસા ચૂકવ્યા હોય તે બધાની પ્રિન્ટ કરેલી નકલ અવશ્ય લો.',
    },
  },
];

export const ADMISSION_CHECKLIST: ChecklistItem[] = [
  {
    id: 'chk-id',
    title: {
      en: 'Patient Photo ID (Aadhaar / Voter ID)',
      hi: 'मरीज़ का सरकारी पहचान पत्र (आधार / वोटर आईडी)',
      gu: 'દર્દીનું સરકારી ઓળખપત્ર (આધાર / ચૂંટણી કાર્ડ)',
    },
    detail: {
      en: 'Carry original plus 2 photocopies, and one ID of the family attendant.',
      hi: 'असली कार्ड के साथ 2 फोटोकॉपी और साथ रहने वाले परिजन का भी पहचान पत्र रखें।',
      gu: 'અસલ કાર્ડ સાથે 2 ઝેરોક્ષ અને સાથે રહેનાર સભ્યનું ઓળખપત્ર પણ રાખો.',
    },
    requiredFor: {
      en: 'Registration & Verification',
      hi: 'पंजीकरण और पहचान',
      gu: 'નોંધણી અને ઓળખ',
    },
  },
  {
    id: 'chk-scheme',
    title: {
      en: 'Government Health Card / Insurance Card',
      hi: 'सरकारी स्वास्थ्य कार्ड / बीमा कार्ड',
      gu: 'સરકારી આરોગ્ય કાર્ડ / વીમા કાર્ડ',
    },
    detail: {
      en: 'Ayushman Bharat (PM-JAY), State MA Card, ESIC, or health insurance papers.',
      hi: 'आयुष्मान भारत (PM-JAY), राज्य कार्ड, ESIC या निजी बीमा के कागज़।',
      gu: 'આયુષ્માન ભારત (PM-JAY), મા કાર્ડ, ESIC કે વીમા પોલિસીના કાગળો.',
    },
    requiredFor: {
      en: 'Scheme / Cashless Desk',
      hi: 'योजना / कैशलेस मदद',
      gu: 'યોજના / કેશલેસ ડેસ્ક',
    },
  },
  {
    id: 'chk-ration',
    title: {
      en: 'Ration Card or Income Certificate',
      hi: 'राशन कार्ड या आय प्रमाण पत्र',
      gu: 'રેશનકાર્ડ અથવા આવકનો દાખલો',
    },
    detail: {
      en: 'Often asked for verification at government or charitable trust hospitals.',
      hi: 'सरकारी या ट्रस्ट अस्पतालों में योजना जांच और छूट के लिए काम आता है।',
      gu: 'સરકારી કે ટ્રસ્ટની હોસ્પિટલમાં યોજનાની તપાસ અને રાહત માટે ઉપયોગી.',
    },
    requiredFor: {
      en: 'Concession / Scheme Check',
      hi: 'सरकारी सहायता जांच',
      gu: 'સરકારી સહાય તપાસ',
    },
  },
  {
    id: 'chk-referral',
    title: {
      en: 'Doctor Referral or Admission Slip',
      hi: 'डॉक्टर की भर्ती पर्ची / रेफरल लेटर',
      gu: 'ડૉક્ટરની દાખલ ચિઠ્ઠી / રેફરલ પત્ર',
    },
    detail: {
      en: 'Written note from the OPD or clinic doctor advising hospital admission.',
      hi: 'ओपीडी या क्लिनिक के डॉक्टर द्वारा लिखी गई भर्ती की सलाह पर्ची।',
      gu: 'ઓપીડી કે ક્લિનિકના ડૉક્ટરે લખી આપેલી દાખલ થવાની ચિઠ્ઠી.',
    },
    requiredFor: {
      en: 'Admission Counter',
      hi: 'भर्ती काउंटर',
      gu: 'એડમિશન કાઉન્ટર',
    },
  },
  {
    id: 'chk-reports',
    title: {
      en: 'Previous Medical Reports & Prescriptions',
      hi: 'पुरानी जांच रिपोर्ट और डॉक्टर के पर्चे',
      gu: 'જૂના મેડિકલ રિપોર્ટ અને દવાની ચિઠ્ઠીઓ',
    },
    detail: {
      en: 'Blood tests, X-ray, scans, discharge papers from past visits, and ongoing medicines.',
      hi: 'खून जांच, एक्स-रे, स्कैन, पुरानी छुट्टी के कागज़ और अभी चल रही दवाइयों के पत्ते।',
      gu: 'લોહીના રિપોર્ટ, એક્સ-રે, સ્કેન, જૂના ડિસ્ચાર્જ પેપર અને હાલની દવાઓ.',
    },
    requiredFor: {
      en: 'Doctor Review',
      hi: 'डॉक्टर की जांच',
      gu: 'ડૉક્ટરની તપાસ',
    },
  },
  {
    id: 'chk-allergy',
    title: {
      en: 'Written Note of Blood Group & Allergies',
      hi: 'ब्लड ग्रुप और किसी एलर्जी की लिखित जानकारी',
      gu: 'બ્લડ ગ્રુપ અને કોઈ એલર્જી હોય તો તેની નોંધ',
    },
    detail: {
      en: 'Note down if the patient has reacted badly to any medicine or food in the past.',
      hi: 'अगर पहले किसी दवा या चीज़ से एलर्जी हुई हो तो कागज़ पर लिखकर रखें।',
      gu: 'જો અગાઉ કોઈ દવા કે ખોરાકથી એલર્જી થઈ હોય તો કાગળ પર લખી રાખો.',
    },
    requiredFor: {
      en: 'Patient Safety',
      hi: 'मरीज़ की सुरक्षा',
      gu: 'દર્દીની સુરક્ષા',
    },
  },
  {
    id: 'chk-contacts',
    title: {
      en: '2 Family Phone Numbers Written on Paper',
      hi: 'परिवार के 2 मोबाइल नंबर कागज़ पर लिखे हुए',
      gu: 'પરિવારના 2 મોબાઇલ નંબર કાગળ પર લખેલા',
    },
    detail: {
      en: 'Helpful if your phone battery runs out during a long hospital stay.',
      hi: 'फोन की बैटरी खत्म होने पर भी अस्पताल परिवार से संपर्क कर सकेगा।',
      gu: 'ફોનની બેટરી પૂરી થઈ જાય તો પણ હોસ્પિટલ પરિવારનો સંપર્ક કરી શકે.',
    },
    requiredFor: {
      en: 'Emergency Contact',
      hi: 'आपात संपर्क',
      gu: 'કટોકટી સંપર્ક',
    },
  },
];

export const FAQ_ITEMS: FaqItem[] = [
  {
    id: 'faq-1',
    question: {
      en: 'What if I cannot read English hospital forms?',
      hi: 'अगर मैं अंग्रेज़ी में लिखे अस्पताल के फ़ॉर्म नहीं पढ़ पाता तो क्या करूँ?',
      gu: 'જો હું અંગ્રેજીમાં લખેલા હોસ્પિટલના ફોર્મ વાંચી ન શકું તો શું કરવું?',
    },
    answer: {
      en: 'Do not sign blindly. Politely ask the nurse, doctor, or help-desk staff to explain every point in Hindi, Gujarati, or your local language, or bring a trusted relative.',
      hi: 'बिना समझे साइन न करें। नर्स, डॉक्टर या हेल्प-डेस्क से अपनी भाषा में हर बात समझाने को कहें, या किसी पढ़े-लिखे भरोसेमंद परिजन को साथ रखें।',
      gu: 'સમજ્યા વગર સહી ન કરો. નર્સ, ડૉક્ટર કે હેલ્પ-ડેસ્કને તમારી ભાષામાં સમજાવવા કહો, અથવા પરિવારના વિશ્વાસુ સભ્યને સાથે રાખો.',
    },
    followUpQuery: {
      en: 'What should I check before signing a hospital consent form?',
      hi: 'सहमति फ़ॉर्म पर साइन करने से पहले क्या जांचें?',
      gu: 'સંમતિ ફોર્મ પર સહી કરતાં પહેલાં શું તપાસવું?',
    },
  },
  {
    id: 'faq-2',
    question: {
      en: 'Can I ask for cheaper generic medicines?',
      hi: 'क्या मैं डॉक्टर से कम कीमत वाली जेनेरिक दवाइयों के बारे में पूछ सकता हूँ?',
      gu: 'શું હું ડૉક્ટરને ઓછી કિંમતની જેનેરિક દવાઓ વિશે પૂછી શકું?',
    },
    answer: {
      en: 'Yes. You can politely ask your doctor if the same medicine is available at a government Jan Aushadhi Kendra or in a lower-cost generic brand. Do not change medicines on your own without asking the doctor.',
      hi: 'हाँ। आप डॉक्टर से पूछ सकते हैं कि क्या वही दवा जन औषधि केंद्र या कम कीमत वाले जेनेरिक नाम से मिल सकती है। डॉक्टर से पूछे बिना खुद दवा न बदलें।',
      gu: 'હા. તમે ડૉક્ટરને પૂછી શકો છો કે શું તે જ દવા જન ઔષધિ કેન્દ્ર પર કે ઓછા ભાવની જેનેરિક બ્રાન્ડમાં મળી શકે છે. ડૉક્ટરને પૂછ્યા વગર જાતે દવા ન બદલો.',
    },
    followUpQuery: {
      en: 'Which government healthcare schemes may help me?',
      hi: 'कौन-सी सरकारी स्वास्थ्य योजनाएँ मेरी मदद कर सकती हैं?',
      gu: 'કઈ સરકારી આરોગ્ય યોજનાઓ મને મદદ કરી શકે છે?',
    },
  },
  {
    id: 'faq-3',
    question: {
      en: 'What papers must I collect before leaving the hospital?',
      hi: 'अस्पताल से छुट्टी (Discharge) के समय कौन-से कागज़ ज़रूर लेने चाहिए?',
      gu: 'હોસ્પિટલમાંથી રજા (Discharge) વખતે કયા કાગળો અવશ્ય લેવા જોઈએ?',
    },
    answer: {
      en: 'Always collect: (1) Signed Discharge Summary, (2) Final Itemized Bill & payment receipts, (3) All blood test / scan reports, and (4) Clear written follow-up date and medicine instructions.',
      hi: 'ये 4 कागज़ ज़रूर लें: (1) डिस्चार्ज समरी, (2) पूरा विस्तृत बिल और सभी रसीदें, (3) सभी जांच रिपोर्ट, और (4) अगली बार डॉक्टर को दिखाने की तारीख व निर्देश।',
      gu: 'આ 4 કાગળો અવશ્ય લો: (1) ડિસ્ચાર્જ સારાંશ, (2) પૂરું વિગતવાર બિલ અને રસીદો, (3) બધા ટેસ્ટ રિપોર્ટ, અને (4) ફરી બતાવવાની તારીખ અને સૂચના.',
    },
    followUpQuery: {
      en: 'How can I understand my hospital bill?',
      hi: 'मैं अपने अस्पताल के बिल को कैसे समझूँ?',
      gu: 'હું મારા હોસ્પિટલના બિલને કેવી રીતે સમજું?',
    },
  },
  {
    id: 'faq-4',
    question: {
      en: 'How do I check if my Ayushman or State Health Card works at a hospital?',
      hi: 'यह कैसे पता चलेगा कि अस्पताल में मेरा आयुष्मान या राज्य स्वास्थ्य कार्ड चलेगा?',
      gu: 'હોસ્પિટલમાં મારું આયુષ્માન કે રાજ્ય આરોગ્ય કાર્ડ ચાલશે કે નહીં તે કેવી રીતે જાણવું?',
    },
    answer: {
      en: 'Before admission, visit the hospital’s "Aarogya Mitra" desk with your card and Aadhaar, or check the official PM-JAY hospital list online / via helpline 14555.',
      hi: 'भर्ती होने से पहले अपना कार्ड और आधार लेकर अस्पताल के "आरोग्य मित्र" डेस्क पर पूछें, या 14555 हेल्पलाइन पर जुड़े हुए अस्पतालों की सूची जांचें।',
      gu: 'દાખલ થતાં પહેલાં તમારું કાર્ડ અને આધાર લઈને હોસ્પિટલના "આરોગ્ય મિત્ર" ડેસ્ક પર પૂછો, અથવા 14555 હેલ્પલાઇન પર જોડાયેલી હોસ્પિટલોની યાદી તપાસો.',
    },
    followUpQuery: {
      en: 'What documents are needed for hospital admission?',
      hi: 'अस्पताल में भर्ती होने के लिए कौन-से कागज़ात चाहिए?',
      gu: 'હોસ્પિટલમાં દાખલ થવા માટે કયા કાગળોની જરૂર પડે છે?',
    },
  },
  {
    id: 'faq-5',
    question: {
      en: 'Can a hospital refuse emergency first aid because we do not have full money ready?',
      hi: 'क्या पूरा पैसा तैयार न होने पर अस्पताल आपातकालीन प्राथमिक इलाज से मना कर सकता है?',
      gu: 'જો પૂરા પૈસા તૈયાર ન હોય તો શું હોસ્પિટલ કટોકટીની પ્રાથમિક સારવાર આપવાની ના પાડી શકે?',
    },
    answer: {
      en: 'In life-threatening medical emergencies, patients have the right to receive immediate stabilizing care. If you face an issue, contact the hospital Medical Superintendent, call 108 for transfer to a government hospital, or call 104.',
      hi: 'जानलेवा आपात स्थिति में मरीज़ को तुरंत जीवन-रक्षक प्राथमिक देखभाल पाने का अधिकार है। समस्या होने पर मेडिकल सुपरिंटेंडेंट से बात करें, या सरकारी अस्पताल जाने के लिए 108 / मदद के लिए 104 पर कॉल करें।',
      gu: 'જીવનું જોખમ હોય તેવી કટોકટીમાં દર્દીને તાત્કાલિક જીવનરક્ષક પ્રાથમિક સારવાર મેળવવાનો અધિકાર છે. મુશ્કેલી પડે તો મેડિકલ સુપરિન્ટેન્ડેન્ટને મળો, અથવા સરકારી હોસ્પિટલ માટે 108 / મદદ માટે 104 પર કૉલ કરો.',
    },
    followUpQuery: {
      en: 'What are my rights as a patient?',
      hi: 'मरीज़ के रूप में मेरे क्या अधिकार हैं?',
      gu: 'દર્દી તરીકે મારા કયા અધિકારો છે?',
    },
  },
];
