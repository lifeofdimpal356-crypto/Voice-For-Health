import { Language } from '../types/sahaay';

export interface UIStrings {
  appName: string;
  heroTitle: string;
  heroSubtitle: string;
  nav: {
    home: string;
    topics: string;
    checklist: string;
    faq: string;
  };
  languageLabel: string;
  mic: {
    tapToSpeak: string;
    listening: string;
    tapToStop: string;
    unavailableTitle: string;
    unavailableDesc: string;
    permissionError: string;
    noSpeechError: string;
    heardPrefix: string;
  };
  input: {
    placeholder: string;
    sendButton: string;
    orTypeHint: string;
  };
  voiceControls: {
    autoSpeak: string;
    listenAnswer: string;
    stopSpeaking: string;
    clearChat: string;
    speakingNow: string;
  };
  sections: {
    sampleQuestionsTitle: string;
    sampleQuestionsSubtitle: string;
    conversationTitle: string;
    followUpTitle: string;
    topicsTitle: string;
    topicsSubtitle: string;
    billExplorerTitle: string;
    billExplorerSubtitle: string;
    billCheckLabel: string;
    askVoiceButton: string;
    listenGuideButton: string;
    checklistTitle: string;
    checklistSubtitle: string;
    checklistProgress: string;
    checklistListenAll: string;
    checklistReset: string;
    faqTitle: string;
    faqSubtitle: string;
  };
  disclaimer: {
    heading: string;
    body: string;
    emergencyNote: string;
  };
  labels: {
    youAsked: string;
    assistantReply: string;
    importantNote: string;
    ready: string;
    of: string;
  };
}

export const UI_STRINGS: Record<Language, UIStrings> = {
  en: {
    appName: 'Sahaay Voice',
    heroTitle: 'Simple Hospital Help, Spoken Clearly',
    heroSubtitle:
      'Ask about operations, hospital bills, government health schemes, admission papers, or patient rights in English, Hindi, or Gujarati.',
    nav: {
      home: 'Voice Help',
      topics: 'Guides',
      checklist: 'Documents',
      faq: 'FAQ',
    },
    languageLabel: 'Language',
    mic: {
      tapToSpeak: 'Tap to Speak',
      listening: 'Listening now... Speak clearly',
      tapToStop: 'Tap to Stop',
      unavailableTitle: 'Voice mic is not available in this browser',
      unavailableDesc:
        'You can type your question below or tap any large question card. Answers will still read aloud.',
      permissionError:
        'Microphone access was blocked. Please allow microphone permission in your browser or type your question below.',
      noSpeechError:
        'No voice was heard. Please tap the microphone again and speak closer to the phone, or type below.',
      heardPrefix: 'Heard:',
    },
    input: {
      placeholder: 'Type your question in English, Hindi, or Gujarati...',
      sendButton: 'Ask',
      orTypeHint: 'Or type your question here',
    },
    voiceControls: {
      autoSpeak: 'Speak answers aloud',
      listenAnswer: 'Listen',
      stopSpeaking: 'Stop Voice',
      clearChat: 'Clear & Start New',
      speakingNow: 'Reading aloud...',
    },
    sections: {
      sampleQuestionsTitle: 'Common Questions — Tap to Ask',
      sampleQuestionsSubtitle: 'Tap any card to hear a simple explanation right away.',
      conversationTitle: 'Your Conversation',
      followUpTitle: 'Related follow-up questions',
      topicsTitle: 'Hospital & Healthcare Guides',
      topicsSubtitle: 'Simple step-by-step information you can read or listen to before visiting a hospital.',
      billExplorerTitle: 'Common Hospital Bill Words Explained',
      billExplorerSubtitle: 'Tap any word on a hospital bill to learn what it means and what to check.',
      billCheckLabel: 'What to check:',
      askVoiceButton: 'Ask in Voice Chat',
      listenGuideButton: 'Listen to This Guide',
      checklistTitle: 'Hospital Admission Document Checklist',
      checklistSubtitle: 'Tap each item as you pack your folder for hospital admission.',
      checklistProgress: 'Documents ready',
      checklistListenAll: 'Listen to Full List',
      checklistReset: 'Reset Checklist',
      faqTitle: 'Frequently Asked Questions',
      faqSubtitle: 'Clear answers to everyday doubts families face at clinics and hospitals.',
    },
    disclaimer: {
      heading: 'General Information Only — Demo Guide',
      body: 'Sahaay Voice shares simple general information to help families understand hospital steps. It does not diagnose illnesses, suggest medicines, or guarantee government scheme eligibility, treatment costs, or legal results. Always check with qualified doctors, hospital desks, lawyers, or official government portals.',
      emergencyNote: 'Medical Emergency: Call 108 (Ambulance) or visit the nearest government hospital emergency room immediately.',
    },
    labels: {
      youAsked: 'You asked',
      assistantReply: 'Sahaay Voice',
      importantNote: 'Important reminder',
      ready: 'ready',
      of: 'of',
    },
  },
  hi: {
    appName: 'सहाय वॉइस',
    heroTitle: 'अस्पताल की जानकारी, सरल आवाज़ में',
    heroSubtitle:
      'ऑपरेशन, अस्पताल के बिल, सरकारी स्वास्थ्य योजनाएँ, भर्ती के कागज़ात और मरीज़ के अधिकारों के बारे में हिन्दी, गुजराती या अंग्रेज़ी में पूछें।',
    nav: {
      home: 'आवाज़ मदद',
      topics: 'जानकारी',
      checklist: 'कागज़ात',
      faq: 'सवाल-जवाब',
    },
    languageLabel: 'भाषा',
    mic: {
      tapToSpeak: 'बोलने के लिए दबाएँ',
      listening: 'सुन रहे हैं... साफ़ आवाज़ में बोलें',
      tapToStop: 'रोकने के लिए दबाएँ',
      unavailableTitle: 'इस ब्राउज़र में माइक उपलब्ध नहीं है',
      unavailableDesc:
        'आप नीचे अपना सवाल लिख सकते हैं या किसी भी कार्ड पर टैप कर सकते हैं। जवाब फिर भी बोलकर सुनाया जाएगा।',
      permissionError:
        'माइक्रोफ़ोन की अनुमति नहीं मिली। कृपया ब्राउज़र सेटिंग में माइक चालू करें या नीचे लिखकर पूछें।',
      noSpeechError:
        'कोई आवाज़ सुनाई नहीं दी। कृपया फिर से माइक दबाकर पास से बोलें, या नीचे टाइप करें।',
      heardPrefix: 'सुना गया:',
    },
    input: {
      placeholder: 'अपना सवाल हिन्दी, अंग्रेज़ी या गुजराती में लिखें...',
      sendButton: 'पूछें',
      orTypeHint: 'या यहाँ अपना सवाल लिखें',
    },
    voiceControls: {
      autoSpeak: 'जवाब बोलकर सुनाएँ',
      listenAnswer: 'सुनें',
      stopSpeaking: 'आवाज़ रोकें',
      clearChat: 'साफ़ करें / नया सवाल',
      speakingNow: 'बोलकर सुना रहे हैं...',
    },
    sections: {
      sampleQuestionsTitle: 'आम सवाल — दबाकर पूछें',
      sampleQuestionsSubtitle: 'सरल जवाब सुनने के लिए किसी भी कार्ड पर टैप करें।',
      conversationTitle: 'आपकी बातचीत',
      followUpTitle: 'आगे के मिलते-जुलते सवाल',
      topicsTitle: 'अस्पताल और स्वास्थ्य मार्गदर्शिका',
      topicsSubtitle: 'अस्पताल जाने से पहले सरल जानकारी पढ़ें या सुनें।',
      billExplorerTitle: 'अस्पताल बिल के आम शब्दों का मतलब',
      billExplorerSubtitle: 'बिल के किसी भी शब्द पर दबाएँ और जानें कि क्या जांचना चाहिए।',
      billCheckLabel: 'क्या जांचें:',
      askVoiceButton: 'आवाज़ चैट में पूछें',
      listenGuideButton: 'यह जानकारी सुनें',
      checklistTitle: 'अस्पताल भर्ती के ज़रूरी कागज़ात की सूची',
      checklistSubtitle: 'अस्पताल जाने का बैग तैयार करते समय हर कागज़ पर सही का निशान लगाएँ।',
      checklistProgress: 'तैयार कागज़ात',
      checklistListenAll: 'पूरी सूची सुनें',
      checklistReset: 'सूची रीसेट करें',
      faqTitle: 'अक्सर पूछे जाने वाले सवाल',
      faqSubtitle: 'अस्पताल और क्लिनिक में परिवारों के रोज़मर्रा के सवालों के आसान जवाब।',
    },
    disclaimer: {
      heading: 'केवल सामान्य जानकारी — डेमो सहायता',
      body: 'सहाय वॉइस केवल सामान्य मार्गदर्शन देता है। यह किसी बीमारी की जांच नहीं करता, कोई दवा नहीं बताता और न ही सरकारी योजना की पात्रता, इलाज के खर्च या कानूनी नतीजों की गारंटी देता है। कृपया हमेशा डॉक्टर, वकील या सरकारी/अस्पताल अधिकारी से पक्की जानकारी लें।',
      emergencyNote: 'आपातकाल (Emergency): तुरंत 108 (एम्बुलेंस) पर कॉल करें या नजदीकी सरकारी अस्पताल जाएँ।',
    },
    labels: {
      youAsked: 'आपका सवाल',
      assistantReply: 'सहाय वॉइस',
      importantNote: 'ज़रूरी बात',
      ready: 'तैयार',
      of: 'में से',
    },
  },
  gu: {
    appName: 'સહાય વૉઇસ',
    heroTitle: 'હોસ્પિટલની સરળ માહિતી, સ્પષ્ટ અવાજમાં',
    heroSubtitle:
      'ઓપરેશન, હોસ્પિટલ બિલ, સરકારી આરોગ્ય યોજનાઓ, દાખલ થવાના કાગળો અને દર્દીના અધિકારો વિશે ગુજરાતી, હિન્દી કે અંગ્રેજીમાં પૂછો.',
    nav: {
      home: 'અવાજ મદદ',
      topics: 'માહિતી',
      checklist: 'કાગળો',
      faq: 'પ્રશ્નો',
    },
    languageLabel: 'ભાષા',
    mic: {
      tapToSpeak: 'બોલવા માટે દબાવો',
      listening: 'સાંભળી રહ્યા છીએ... સ્પષ્ટ અવાજમાં બોલો',
      tapToStop: 'બંધ કરવા દબાવો',
      unavailableTitle: 'આ બ્રાઉઝરમાં માઇક ઉપલબ્ધ નથી',
      unavailableDesc:
        'તમે નીચે તમારો પ્રશ્ન લખી શકો છો અથવા કોઈપણ કાર્ડ પર ટૅપ કરી શકો છો. જવાબ હજી પણ બોલીને સંભળાવવામાં આવશે.',
      permissionError:
        'માઇક્રોફોનની પરવાનગી મળી નથી. કૃપા કરીને બ્રાઉઝરમાં માઇક ચાલુ કરો અથવા નીચે લખીને પૂછો.',
      noSpeechError:
        'કોઈ અવાજ સંભળાયો નહીં. કૃપા કરીને ફરી માઇક દબાવીને નજીકથી બોલો, અથવા નીચે લખો.',
      heardPrefix: 'સાંભળેલું:',
    },
    input: {
      placeholder: 'તમારો પ્રશ્ન ગુજરાતી, હિન્દી કે અંગ્રેજીમાં લખો...',
      sendButton: 'પૂછો',
      orTypeHint: 'અથવા અહીં તમારો પ્રશ્ન લખો',
    },
    voiceControls: {
      autoSpeak: 'જવાબ બોલીને સંભળાવો',
      listenAnswer: 'સાંભળો',
      stopSpeaking: 'અવાજ બંધ કરો',
      clearChat: 'સાફ કરો / નવો પ્રશ્ન',
      speakingNow: 'બોલીને સંભળાવે છે...',
    },
    sections: {
      sampleQuestionsTitle: 'સામાન્ય પ્રશ્નો — દબાવીને પૂછો',
      sampleQuestionsSubtitle: 'સરળ સમજૂતી સાંભળવા માટે કોઈપણ કાર્ડ પર ટૅપ કરો.',
      conversationTitle: 'તમારી વાતચીત',
      followUpTitle: 'સંબંધિત વધુ પ્રશ્નો',
      topicsTitle: 'હોસ્પિટલ અને આરોગ્ય માર્ગદર્શિકા',
      topicsSubtitle: 'હોસ્પિટલ જતાં પહેલાં સરળ માહિતી વાંચો અથવા સાંભળો.',
      billExplorerTitle: 'હોસ્પિટલ બિલના સામાન્ય શબ્દોની સમજૂતી',
      billExplorerSubtitle: 'બિલના કોઈપણ શબ્દ પર ટૅપ કરો અને જાણો કે શું તપાસવું જોઈએ.',
      billCheckLabel: 'શું તપાસવું:',
      askVoiceButton: 'અવાજ ચૅટમાં પૂછો',
      listenGuideButton: 'આ માહિતી સાંભળો',
      checklistTitle: 'હોસ્પિટલમાં દાખલ થવાના કાગળોની યાદી',
      checklistSubtitle: 'હોસ્પિટલ જતી વખતે દરેક કાગળ તૈયાર કરીને નિશાન લગાવો.',
      checklistProgress: 'તૈયાર કાગળો',
      checklistListenAll: 'આખી યાદી સાંભળો',
      checklistReset: 'યાદી ફરીથી શરૂ કરો',
      faqTitle: 'વારંવાર પૂછાતા પ્રશ્નો',
      faqSubtitle: 'હોસ્પિટલ અને દવાખાનામાં પરિવારોને થતા રોજિંદા પ્રશ્નોના સરળ જવાબ.',
    },
    disclaimer: {
      heading: 'ફક્ત સામાન્ય માહિતી — ડેમો માર્ગદર્શિકા',
      body: 'સહાય વૉઇસ ફક્ત સામાન્ય માહિતી આપે છે. તે કોઈ રોગનું નિદાન કરતું નથી, દવાની સલાહ આપતું નથી, અને સરકારી યોજનાની પાત્રતા, સારવારનો ખર્ચ કે કાનૂની પરિણામની ખાતરી આપતું નથી. હંમેશા ડૉક્ટર, વકીલ કે સરકારી/હોસ્પિટલ અધિકારી પાસેથી ખાતરી કરો.',
      emergencyNote: 'કટોકટી (Emergency): તરત 108 (એમ્બ્યુલન્સ) પર કૉલ કરો અથવા નજીકની સરકારી હોસ્પિટલના ઇમરજન્સી વિભાગમાં જાઓ.',
    },
    labels: {
      youAsked: 'તમારો પ્રશ્ન',
      assistantReply: 'સહાય વૉઇસ',
      importantNote: 'મહત્વની નોંધ',
      ready: 'તૈયાર',
      of: 'માંથી',
    },
  },
};
