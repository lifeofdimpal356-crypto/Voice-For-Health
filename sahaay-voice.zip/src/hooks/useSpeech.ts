import { useCallback, useEffect, useRef, useState } from 'react';
import { Language } from '../types/sahaay';

interface SpeechRecognitionAlternativeLike {
  transcript: string;
}

interface SpeechRecognitionResultLike {
  isFinal: boolean;
  0: SpeechRecognitionAlternativeLike;
}

interface SpeechRecognitionEventLike {
  results: ArrayLike<SpeechRecognitionResultLike>;
}

interface SpeechRecognitionErrorEventLike {
  error: string;
}

interface SpeechRecognitionLike {
  lang: string;
  interimResults: boolean;
  continuous: boolean;
  maxAlternatives: number;
  onstart: (() => void) | null;
  onresult: ((event: SpeechRecognitionEventLike) => void) | null;
  onerror: ((event: SpeechRecognitionErrorEventLike) => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
  abort: () => void;
}

type SpeechRecognitionConstructor = new () => SpeechRecognitionLike;

function getSpeechRecognitionCtor(): SpeechRecognitionConstructor | null {
  if (typeof window === 'undefined') return null;
  const win = window as unknown as {
    SpeechRecognition?: SpeechRecognitionConstructor;
    webkitSpeechRecognition?: SpeechRecognitionConstructor;
  };
  return win.SpeechRecognition || win.webkitSpeechRecognition || null;
}

const LOCALE_MAP: Record<Language, string> = {
  en: 'en-IN',
  hi: 'hi-IN',
  gu: 'gu-IN',
};

export type MicErrorType = 'permission' | 'no-speech' | 'generic' | null;

export function useSpeech(language: Language) {
  const [isListening, setIsListening] = useState(false);
  const [interimTranscript, setInterimTranscript] = useState('');
  const [micError, setMicError] = useState<MicErrorType>(null);
  const [speakingId, setSpeakingId] = useState<string | null>(null);
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);

  const recognitionRef = useRef<SpeechRecognitionLike | null>(null);
  const isRecognitionSupported = typeof window !== 'undefined' && getSpeechRecognitionCtor() !== null;
  const isTtsSupported = typeof window !== 'undefined' && 'speechSynthesis' in window;

  useEffect(() => {
    if (!isTtsSupported) return;
    const loadVoices = () => {
      const available = window.speechSynthesis.getVoices();
      if (available.length > 0) {
        setVoices(available);
      }
    };
    loadVoices();
    window.speechSynthesis.addEventListener?.('voiceschanged', loadVoices);
    return () => {
      window.speechSynthesis.removeEventListener?.('voiceschanged', loadVoices);
    };
  }, [isTtsSupported]);

  const stopSpeaking = useCallback(() => {
    if (!isTtsSupported) return;
    window.speechSynthesis.cancel();
    setSpeakingId(null);
  }, [isTtsSupported]);

  const speak = useCallback(
    (text: string, id: string) => {
      if (!isTtsSupported) return;
      window.speechSynthesis.cancel();

      const cleaned = text.replace(/\s+/g, ' ').trim();
      if (!cleaned) return;

      const utterance = new SpeechSynthesisUtterance(cleaned);
      const targetLocale = LOCALE_MAP[language];
      utterance.lang = targetLocale;
      utterance.rate = 0.94; // Slightly slower & clearer for elderly and families
      utterance.pitch = 1.0;

      // Pick best matching voice if installed
      const exactVoice = voices.find((v) => v.lang.toLowerCase() === targetLocale.toLowerCase());
      const prefixVoice = voices.find((v) =>
        v.lang.toLowerCase().startsWith(language === 'en' ? 'en' : language)
      );
      if (exactVoice) {
        utterance.voice = exactVoice;
      } else if (prefixVoice) {
        utterance.voice = prefixVoice;
      }

      utterance.onstart = () => setSpeakingId(id);
      utterance.onend = () => setSpeakingId((curr) => (curr === id ? null : curr));
      utterance.onerror = () => setSpeakingId((curr) => (curr === id ? null : curr));

      setSpeakingId(id);
      window.speechSynthesis.speak(utterance);
    },
    [isTtsSupported, language, voices]
  );

  const stopListening = useCallback(() => {
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch {
        // Ignore stop errors if already stopped
      }
    }
    setIsListening(false);
  }, []);

  const startListening = useCallback(
    (onFinalTranscript: (transcript: string) => void) => {
      const Ctor = getSpeechRecognitionCtor();
      if (!Ctor) {
        setMicError('generic');
        return;
      }

      // Stop any ongoing TTS before listening so mic doesn't record speaker
      stopSpeaking();
      setMicError(null);
      setInterimTranscript('');

      try {
        if (recognitionRef.current) {
          recognitionRef.current.abort();
        }

        const recognition = new Ctor();
        recognition.lang = LOCALE_MAP[language];
        recognition.interimResults = true;
        recognition.continuous = false;
        recognition.maxAlternatives = 1;

        let capturedFinal = '';

        recognition.onstart = () => {
          setIsListening(true);
        };

        recognition.onresult = (event: SpeechRecognitionEventLike) => {
          let interim = '';
          let finalText = '';
          for (let i = 0; i < event.results.length; i++) {
            const res = event.results[i];
            const piece = res[0]?.transcript || '';
            if (res.isFinal) {
              finalText += piece + ' ';
            } else {
              interim += piece;
            }
          }
          if (interim) {
            setInterimTranscript(interim.trim());
          }
          if (finalText.trim()) {
            capturedFinal = finalText.trim();
            setInterimTranscript(capturedFinal);
          }
        };

        recognition.onerror = (event: SpeechRecognitionErrorEventLike) => {
          if (event.error === 'not-allowed' || event.error === 'service-not-allowed') {
            setMicError('permission');
          } else if (event.error === 'no-speech') {
            setMicError('no-speech');
          } else if (event.error !== 'aborted') {
            setMicError('generic');
          }
          setIsListening(false);
        };

        recognition.onend = () => {
          setIsListening(false);
          if (capturedFinal) {
            onFinalTranscript(capturedFinal);
            setInterimTranscript('');
          }
        };

        recognitionRef.current = recognition;
        recognition.start();
      } catch {
        setMicError('generic');
        setIsListening(false);
      }
    },
    [language, stopSpeaking]
  );

  useEffect(() => {
    return () => {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.abort();
        } catch {
          // ignore
        }
      }
      if (isTtsSupported) {
        window.speechSynthesis.cancel();
      }
    };
  }, [isTtsSupported]);

  return {
    isRecognitionSupported,
    isTtsSupported,
    isListening,
    interimTranscript,
    micError,
    clearMicError: () => setMicError(null),
    speakingId,
    startListening,
    stopListening,
    speak,
    stopSpeaking,
  };
}
