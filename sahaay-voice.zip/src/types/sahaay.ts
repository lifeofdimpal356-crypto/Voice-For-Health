export type Language = 'en' | 'hi' | 'gu';

export type NavTab = 'home' | 'topics' | 'checklist' | 'faq';

export type TopicId = 'operation' | 'bill' | 'schemes' | 'rights';

export interface LocalizedText {
  en: string;
  hi: string;
  gu: string;
}

export interface LocalizedList {
  en: string[];
  hi: string[];
  gu: string[];
}

export interface FollowUpOption {
  id: string;
  label: LocalizedText;
  query: LocalizedText;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  title?: string;
  text: string;
  points?: string[];
  note?: string;
  followUps?: FollowUpOption[];
  isSafetyNotice?: boolean;
  timestamp: string;
}

export interface KnowledgeIntent {
  id: string;
  category: TopicId | 'admission' | 'general' | 'safety';
  keywords: string[];
  title: LocalizedText;
  summary: LocalizedText;
  points: LocalizedList;
  note?: LocalizedText;
  followUps: FollowUpOption[];
}

export interface SampleQuestion {
  id: string;
  topic: TopicId | 'admission';
  question: LocalizedText;
}

export interface BillTerm {
  id: string;
  term: LocalizedText;
  simpleMeaning: LocalizedText;
  whatToCheck: LocalizedText;
}

export interface TopicGuide {
  id: TopicId;
  title: LocalizedText;
  subtitle: LocalizedText;
  intro: LocalizedText;
  sections: {
    heading: LocalizedText;
    bullets: LocalizedList;
  }[];
  sampleQuestion: LocalizedText;
}

export interface ChecklistItem {
  id: string;
  title: LocalizedText;
  detail: LocalizedText;
  requiredFor: LocalizedText;
}

export interface FaqItem {
  id: string;
  question: LocalizedText;
  answer: LocalizedText;
  followUpQuery: LocalizedText;
}
