import { FALLBACK_INTENT, KNOWLEDGE_INTENTS } from '../data/knowledgeBase';
import { KnowledgeIntent, Language } from '../types/sahaay';

/**
 * Detects if user text is mostly Hindi (Devanagari), Gujarati script, or Latin/English.
 * Used only as a gentle tie-breaker if needed; responses respect the selected UI language
 * while understanding mixed-language (Hinglish / Gujlish / English / Hindi / Gujarati) queries.
 */
export function detectQueryLanguageHint(query: string): Language | null {
  if (/[\u0A80-\u0AFF]/.test(query)) return 'gu';
  if (/[\u0900-\u097F]/.test(query)) return 'hi';
  return null;
}

/**
 * Matches a user's voice or text question (including Hinglish, Gujlish, Hindi, Gujarati, English)
 * against the demo knowledge base, prioritizing medical safety guardrails first.
 */
export function matchQuestionIntent(rawQuery: string): KnowledgeIntent {
  const query = rawQuery.trim().toLowerCase();
  if (!query) return FALLBACK_INTENT;

  // 1. Check safety guardrail first (diagnoses, medicines, prescriptions, symptoms)
  const safetyIntent = KNOWLEDGE_INTENTS.find((intent) => intent.id === 'medical-safety-guardrail');
  if (safetyIntent) {
    const safetyMatches = safetyIntent.keywords.filter((kw) => query.includes(kw.toLowerCase()));
    // Only trigger safety guardrail if user is NOT explicitly asking about bills/schemes/rights/documents
    const adminKeywords = ['bill', 'scheme', 'ayushman', 'right', 'document', 'admission', 'checklist', 'बिल', 'योजना', 'अधिकार', 'कागज़', 'બિલ', 'યોજના', 'અધિકાર', 'કાગળ'];
    const hasAdminIntent = adminKeywords.some((kw) => query.includes(kw));
    if (safetyMatches.length > 0 && !hasAdminIntent) {
      return safetyIntent;
    }
  }

  // 2. Score all remaining intents by keyword hits + phrase specificity
  let bestIntent: KnowledgeIntent | null = null;
  let bestScore = 0;

  for (const intent of KNOWLEDGE_INTENTS) {
    if (intent.id === 'medical-safety-guardrail') continue;

    let score = 0;
    for (const kw of intent.keywords) {
      const lowerKw = kw.toLowerCase();
      if (query.includes(lowerKw)) {
        // Multi-word or longer keywords get slightly higher weight
        score += lowerKw.includes(' ') ? 3 : 2;
      }
    }

    // Bonus for exact title similarity
    if (
      query.includes('before') &&
      (query.includes('operation') || query.includes('surgery')) &&
      intent.id === 'before-operation'
    ) {
      score += 4;
    }

    if (
      (query.includes('estimate') || query.includes('cost') || query.includes('kharch')) &&
      (query.includes('operation') || query.includes('surgery')) &&
      intent.id === 'operation-cost-estimate'
    ) {
      score += 4;
    }

    if (score > bestScore) {
      bestScore = score;
      bestIntent = intent;
    }
  }

  return bestIntent && bestScore > 0 ? bestIntent : FALLBACK_INTENT;
}
